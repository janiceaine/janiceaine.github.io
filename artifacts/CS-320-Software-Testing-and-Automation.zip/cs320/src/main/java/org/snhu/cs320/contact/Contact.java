/*
 * Contact.java
 * Author: Janice Ainebabazi
 * CS-499 Capstone | SNHU 2026
 * Original artifact: CS-320 Software Testing and Automation, 2024
 *
 * This class represents a single contact in a contact management system.
 * It was one of the first Java classes I built from scratch in CS-320
 * and taught me how to apply input validation directly inside a class
 * rather than leaving it up to the caller to check.
 *
 * WHAT I LEARNED:
 * - The difference between final and non-final fields.
 *   contactId is final because a contact's ID should never change after creation.
 *   The other fields (name, phone, address) can be updated so they are not final.
 *
 * - How to throw exceptions with descriptive messages so the calling code
 *   knows exactly what went wrong instead of just getting a silent failure.
 *
 * - The importance of validation at the model level. If I only validated
 *   in ContactService, someone could create a Contact object with bad data
 *   and bypass the service entirely. Validating in the constructor prevents that.
 *
 * CS-320 CONCEPTS APPLIED:
 * - Defensive programming: every setter validates before setting the value
 * - Immutable ID: once set, contactId cannot be changed
 * - IllegalArgumentException for invalid inputs (standard Java convention)
 */
package org.snhu.cs320.contact;

public class Contact {

    // contactId is final - it is set once at construction and never changes.
    // This is called an immutable field. It makes sense for an ID because
    // changing it after creation could break lookups in the service layer.
    private final String contactId;

    // These fields can be updated after creation, so they are not final
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String address;

    /*
     * Constructor creates a new Contact and validates every field.
     * I learned in CS-320 that validation should happen as early as possible.
     * If bad data gets in here, it is harder to catch later.
     *
     * Field rules from the CS-320 requirements:
     *   contactId   - not null, max 10 characters
     *   firstName   - not null, max 10 characters
     *   lastName    - not null, max 10 characters
     *   phoneNumber - not null, exactly 10 digits
     *   address     - not null, max 30 characters
     */
    public Contact(String contactId, String firstName, String lastName,
                   String phoneNumber, String address) {

        // Validate contactId - null check comes first to avoid NullPointerException
        if (contactId == null || contactId.length() > 10)
            throw new IllegalArgumentException("Invalid contact ID");

        // First and last name have the same 10-character limit
        if (firstName == null || firstName.length() > 10)
            throw new IllegalArgumentException("Invalid first name");
        if (lastName == null || lastName.length() > 10)
            throw new IllegalArgumentException("Invalid last name");

        // Phone number must be exactly 10 characters not more, not less
        if (phoneNumber == null || phoneNumber.length() != 10)
            throw new IllegalArgumentException("Phone number must be exactly 10 digits");

        // Address has a larger limit of 30 characters
        if (address == null || address.length() > 30)
            throw new IllegalArgumentException("Invalid address");

        // All validations passed, safe to assign the fields
        this.contactId   = contactId;
        this.firstName   = firstName;
        this.lastName    = lastName;
        this.phoneNumber = phoneNumber;
        this.address     = address;
    }

    // Getters
    // Getters allow other classes to read field values without giving them
    // direct access to the fields. This is called encapsulation - one of
    // the four main principles of object-oriented programming from IT-145.

    public String getContactId()   { return contactId; }
    public String getFirstName()   { return firstName; }
    public String getLastName()    { return lastName; }
    public String getPhoneNumber() { return phoneNumber; }
    public String getAddress()     { return address; }

    // Setters
    // There is no setContactId() because the ID is final and should never change.
    // Each setter below re-applies the same validation rules from the constructor.
    // I learned that it is important to keep validation consistent, if the
    // rules change, I update them in one place and both constructor and setter
    // stay in sync.

    public void setFirstName(String firstName) {
        // Validate before setting, never trust incoming data
        if (firstName == null || firstName.length() > 10)
            throw new IllegalArgumentException("Invalid first name");
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() > 10)
            throw new IllegalArgumentException("Invalid last name");
        this.lastName = lastName;
    }

    public void setPhoneNumber(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.length() != 10)
            throw new IllegalArgumentException("Phone number must be exactly 10 digits");
        this.phoneNumber = phoneNumber;
    }

    public void setAddress(String address) {
        if (address == null || address.length() > 30)
            throw new IllegalArgumentException("Invalid address");
        this.address = address;
    }

    /*
     * toString() gives a readable text version of the contact.
     * I added this so that when I print a Contact during debugging or testing
     * I can actually see the field values instead of a memory address like
     * "org.snhu.cs320.contact.Contact@3764951d"
     */
    @Override
    public String toString() {
        return "Contact [ID=" + contactId + ", Name=" + firstName + " " + lastName
                + ", Phone=" + phoneNumber + ", Address=" + address + "]";
    }
}
