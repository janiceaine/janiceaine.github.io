/*
 * ContactService.java
 * Author: Janice Ainembabazi
 * CS-499 Capstone | SNHU 2026
 * Original artifact: CS-320 Software Testing and Automation, 2024
 *
 * This class manages a collection of Contact objects. It is the service layer
 * between the data (Contact) and anything that needs to use contacts.
 *
 * WHAT I LEARNED:
 * - The service layer pattern: the Contact class knows about one contact,
 *   and ContactService knows about all of them. Keeping these responsibilities
 *   separate made the code easier to test because I could test Contact by itself
 *   and ContactService by itself without them depending on each other too much.
 *
 * - HashMap is a great choice here because I almost always look up contacts
 *   by their ID. HashMap gives me O(1) average time for get, put, and remove,
 *   which means the time it takes does not grow as more contacts are added.
 *   I learned about Big O notation in CS-260 and it helped me understand why
 *   HashMap was better here than a list where I would have to search through
 *   every item to find the right one.
 *
 * - Defensive copying in getContacts(): returning a new HashMap instead of
 *   the internal one means callers cannot accidentally modify the stored data.
 *   This is a pattern I learned about in CS-405 Secure Coding.
 *
 * CS-320 CONCEPTS APPLIED:
 * - HashMap for the in-memory data store
 * - Returning boolean to signal success or failure instead of throwing for
 *   every case (add returns false for duplicates rather than throwing)
 * - Each update method only changes one field at a time, matching the
 *   requirements from the CS-320 project specification
 */
package org.snhu.cs320.contact;

import java.util.HashMap;
import java.util.Map;

public class ContactService {

    // HashMap stores contacts keyed by contactId.
    // Key = contactId (String), Value = Contact object.
    // Using contactId as the key means lookup is O(1) [very fast regardless]
    // of how many contacts are stored.
    private final Map<String, Contact> contacts = new HashMap<>();

    /*
     * addContact() adds a new contact to the collection.
     * Returns true if the contact was added successfully.
     * Returns false if a contact with the same ID already exists.
     *
     * I chose to return a boolean here instead of throwing an exception
     * because a duplicate is a normal situation (the user just tried to add
     * something twice) rather than an unexpected error.
     */
    public boolean addContact(Contact contact) {
        // containsKey() checks if the ID is already in use [O(1) with HashMap]
        if (contacts.containsKey(contact.getContactId())) return false;
        contacts.put(contact.getContactId(), contact);
        return true;
    }

    /*
     * deleteContact() removes a contact by ID.
     * Returns true if the contact was found and removed.
     * Returns false if no contact with that ID exists.
     *
     * HashMap.remove() returns the removed value or null if not found,
     * so the != null check tells me whether the removal actually happened.
     */
    public boolean deleteContact(String contactId) {
        return contacts.remove(contactId) != null;
    }

    /*
     * Update methods one for each updatable field.
     * Each method looks up the contact by ID, then delegates to the
     * Contact setter which handles validation.
     *
     * I learned in CS-320 that each method should do one thing.
     * Having separate update methods for each field follows the
     * Single Responsibility Principle from IT-145.
     */

    // Updates first name then returns false if contact not found
    public boolean updateContactFirstName(String contactId, String newFirstName) {
        Contact c = contacts.get(contactId);
        if (c == null) return false;
        c.setFirstName(newFirstName); // validation happens inside Contact
        return true;
    }

    // Updates last name then returns false if contact not found
    public boolean updateContactLastName(String contactId, String newLastName) {
        Contact c = contacts.get(contactId);
        if (c == null) return false;
        c.setLastName(newLastName);
        return true;
    }

    // Updates phone number then returns false if contact not found
    public boolean updateContactPhoneNumber(String contactId, String newPhoneNumber) {
        Contact c = contacts.get(contactId);
        if (c == null) return false;
        c.setPhoneNumber(newPhoneNumber);
        return true;
    }

    // Updates address then returns false if contact not found
    public boolean updateContactAddress(String contactId, String newAddress) {
        Contact c = contacts.get(contactId);
        if (c == null) return false;
        c.setAddress(newAddress);
        return true;
    }

    /*
     * getContacts() returns a copy of the contacts map.
     * Returning a copy (defensive copy) instead of the real map means
     * callers cannot add, remove, or replace contacts by modifying the
     * returned map directly. I learned this pattern in CS-405.
     */
    public Map<String, Contact> getContacts() {
        return new HashMap<>(contacts);
    }

    // Prints all contacts to the console [useful for debugging]
    public void displayAllContacts() {
        contacts.values().forEach(System.out::println);
    }
}
