/*
 * AppointmentService.java
 * Author: Janice Ainembabazi
 * CS-499 Capstone | SNHU 2026
 * Original artifact: CS-320 Software Testing and Automation, 2024
 *
 * This class manages a collection of Appointment objects.
 * The original CS-320 version used only a HashMap for storage.
 *
 * CS-499 ENHANCEMENT TreeMap:
 * I added a second data structure, a TreeMap<Date, Appointment>, that
 * keeps appointments in chronological order automatically.
 *
 * WHAT I LEARNED:
 * - TreeMap vs HashMap: this was the biggest concept I learned for this enhancement.
 *
 *   HashMap stores entries with no guaranteed order. If you add appointments
 *   for Monday, Wednesday, and Friday in that order, iterating the HashMap might
 *   give you Friday, Monday, Wednesday, or any other order. Fast but unordered.
 *
 *   TreeMap stores entries sorted by their key. Because the key here is a Date
 *   object and Date implements the Comparable interface, TreeMap automatically
 *   keeps the entries in chronological order (earliest date first). You pay a
 *   small cost in performance {O(log n) for insert and lookup instead of O(1)}
 *   but you gain guaranteed sorted order.
 *
 * - When to use which:
 *   If I only need to look up appointments by ID, HashMap is faster.
 *   If I need to find the next upcoming appointment or list them in date order,
 *   TreeMap is the right choice. I keep both structures here and use each
 *   for what it is best at.
 *
 * - TreeMap.firstEntry() returns the entry with the smallest key (earliest date)
 *   in O(log n) time. Without the TreeMap I would have to search through all
 *   appointments to find the earliest one, which would be O(n).
 *
 * - Keeping two structures in sync: every time I add or delete an appointment,
 *   I have to update both the HashMap and the TreeMap. I made sure both updates
 *   happen in the same method so they never get out of sync.
 *
 * CS-320 CONCEPTS APPLIED:
 * - HashMap for O(1) ID-based lookup
 * - ValidationException for duplicate IDs
 * - Defensive copying in getAppointments()
 *
 * CS-499 CONCEPTS ADDED:
 * - TreeMap for automatic chronological ordering
 * - firstEntry() for O(log n) minimum key lookup
 * - Trade-off analysis: HashMap speed vs TreeMap ordering
 */
package org.snhu.cs320.appointment;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import jakarta.validation.ValidationException;

public class AppointmentService {

    // HashMap for fast O(1) lookup by appointment ID.
    // Used for add, delete, and getAppointments() the original operations.
    private final Map<String, Appointment> appointments;

    // TreeMap added for the CS-499 enhancement.
    // Key = appointmentDate (Date), Value = Appointment object.
    // TreeMap sorts entries by key automatically. Because Date implements
    // Comparable, earlier dates are always stored before later ones.
    // This gives us chronological ordering without any extra sorting code.
    private final TreeMap<Date, Appointment> appointmentsByDate;

    public AppointmentService() {
        appointments       = new HashMap<>();
        appointmentsByDate = new TreeMap<>();
    }

    /*
     * addAppointment() adds a new appointment to both the HashMap and TreeMap.
     * Throws ValidationException if the ID already exists.
     *
     * Important: both structures are updated in the same method call.
     * If only the HashMap were updated and the TreeMap were forgotten,
     * date-based queries would give wrong results. Keeping them in sync
     * here makes sure that never happens.
     */
    public void addAppointment(Appointment appointment) {
        if (appointments.containsKey(appointment.getAppointmentId()))
            throw new ValidationException("Appointment with this ID already exists.");

        // Add to HashMap for ID-based access
        appointments.put(appointment.getAppointmentId(), appointment);

        // Add to TreeMap using appointmentDate as the key.
        // The TreeMap will automatically place it in the right position
        // based on the date's natural ordering.
        appointmentsByDate.put(appointment.getAppointmentDate(), appointment);

        System.out.println("Added: " + appointment);
    }

    /*
     * deleteAppointment() removes an appointment from both structures.
     * Using the appointment's date to remove it from the TreeMap ensures
     * both structures stay in sync after every deletion.
     */
    public void deleteAppointment(String appointmentId) {
        // Remove from HashMap and get the removed object back
        Appointment removed = appointments.remove(appointmentId);
        if (removed != null) {
            // Use the removed appointment's date to also remove from TreeMap
            appointmentsByDate.remove(removed.getAppointmentDate());
            System.out.println("Deleted appointment ID: " + appointmentId);
        } else {
            System.out.println("No appointment found with ID: " + appointmentId);
        }
    }

    /*
     * getAppointments() returns a defensive copy of the ID-keyed map.
     * Same pattern as ContactService and TaskService.
     */
    public Map<String, Appointment> getAppointments() {
        return new HashMap<>(appointments);
    }

    /*
     * getAppointmentsSortedByDate() CS-499 ENHANCEMENT
     *
     * Returns all appointments in chronological order (earliest first).
     * TreeMap.values() returns a Collection backed by the TreeMap in key order,
     * so wrapping it in an ArrayList gives us a sorted list with no extra work.
     *
     * This is the main benefit of the TreeMap: sorted access is free because
     * the TreeMap maintains the order as items are added.
     */
    public List<Appointment> getAppointmentsSortedByDate() {
        // TreeMap.values() returns entries in ascending key (date) order automatically
        return new ArrayList<>(appointmentsByDate.values());
    }

    /*
     * getNextAppointment() CS-499 ENHANCEMENT
     *
     * Returns the earliest upcoming appointment without removing it.
     * TreeMap.firstEntry() returns the entry with the smallest key (earliest date)
     * in O(log n) time.
     *
     * Without the TreeMap this would require O(n) time to search through all
     * appointments and find the minimum date. With the TreeMap, the minimum
     * is always at the front and can be retrieved very quickly.
     *
     * Returns null if no appointments are scheduled.
     */
    public Appointment getNextAppointment() {
        if (appointmentsByDate.isEmpty()) return null;
        // firstEntry() returns the entry with the minimum key without removing it
        return appointmentsByDate.firstEntry().getValue();
    }

    // Prints all appointments in chronological order using the TreeMap
    public void printAllAppointments() {
        if (appointmentsByDate.isEmpty()) {
            System.out.println("No appointments scheduled.");
        } else {
            System.out.println("Appointments in chronological order:");
            appointmentsByDate.forEach((date, appt) ->
                    System.out.println("  " + date + "  ->  " + appt.getDescription()));
        }
    }
}
