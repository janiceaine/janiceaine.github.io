/*
 * TaskService.java
 * Author: Janice Ainembabazi
 * CS-499 Capstone | SNHU 2026
 * Original artifact: CS-320 Software Testing and Automation, 2024
 *
 * This class manages a collection of Task objects. The original version
 * from CS-320 used a HashMap for storage and supported add, delete,
 * update, and get operations.
 *
 * CS-499 ENHANCEMENT: PriorityQueue
 * I added two new methods that use a PriorityQueue to return tasks sorted
 * by priority from most urgent (1) to least urgent (3).
 *
 * WHAT I LEARNED:
 * - PriorityQueue is a data structure that always gives you the "smallest"
 *   or "highest priority" item first when you call poll() or peek().
 *   By default it uses natural ordering, but you can pass a Comparator
 *   to define what "smallest" means for your objects.
 *
 * - Comparator.comparingInt(Task::getPriority) creates a comparator that
 *   compares tasks by their getPriority() return value. Lower numbers come
 *   out first, so a task with priority 1 will always be polled before
 *   a task with priority 3.
 *
 * - I chose to build the PriorityQueue on demand (inside the method) rather
 *   than maintaining a second permanent data structure. This means I only
 *   pay the sorting cost when I actually need sorted results. The HashMap
 *   handles everything else in O(1) time.
 *
 * - The difference between poll() and peek():
 *     poll()  - removes and returns the head of the queue
 *     peek()  - returns the head WITHOUT removing it
 *   I use poll() in getTasksByPriority() to drain the queue into a list,
 *   and peek() in peekHighestPriorityTask() because I just want to look.
 *
 * - Defensive copying in getTasks() and cloneTask(): I always return copies
 *   so external code cannot modify the stored tasks directly. This is a
 *   secure coding practice from CS-405.
 *
 * CS-320 CONCEPTS APPLIED:
 * - HashMap for O(1) add, delete, and lookup by ID
 * - Custom exception (TaskAlreadyExistsException) for duplicate IDs
 * - Defensive copying to protect internal state
 *
 * CS-499 CONCEPTS ADDED:
 * - PriorityQueue with a custom Comparator for priority-based sorting
 * - Method reference (Task::getPriority) as a Comparator argument
 */
package org.snhu.cs320.task;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

public class TaskService {

    // HashMap stores all tasks keyed by task ID.
    // Chosen because we almost always look up tasks by ID and HashMap
    // gives us O(1) average time for get, put, and remove operations.
    private final Map<String, Task> tasks;

    public TaskService() {
        tasks = new HashMap<>();
    }

    /*
     * addTask() adds a new task to the collection.
     * Throws TaskAlreadyExistsException if the ID is already in use.
     *
     * I store a cloned copy of the task (not the original object) so
     * if the caller changes the Task object after adding it, the stored
     * version is not affected. This is called defensive copying.
     */
    public void addTask(Task task) throws TaskAlreadyExistsException {
        if (tasks.containsKey(task.getId()))
            throw new TaskAlreadyExistsException("Task with ID " + task.getId() + " already exists.");
        tasks.put(task.getId(), cloneTask(task));
    }

    /*
     * deleteTaskById() removes a task by ID.
     * HashMap.remove() handles the case where the ID does not exist
     * by doing nothing, so no extra check is needed here.
     */
    public void deleteTaskById(String taskId) {
        tasks.remove(taskId);
    }

    /*
     * updateTask() replaces a stored task with a new version.
     * This overwrites whatever was stored at that ID.
     * Again uses cloneTask() to store a defensive copy.
     */
    public Task updateTask(Task task) {
        tasks.put(task.getId(), cloneTask(task));
        return task;
    }

    /*
     * getTasks() returns a copy of the task map.
     * Returning a new HashMap instead of the internal one means callers
     * cannot accidentally add or remove tasks by modifying the returned map.
     */
    public Map<String, Task> getTasks() {
        return new HashMap<>(tasks);
    }

    /*
     * getTasksByPriority() CS-499 ENHANCEMENT
     *
     * Returns all tasks sorted from highest priority (1) to lowest (3).
     * This method demonstrates using a PriorityQueue with a custom Comparator.
     *
     * Steps:
     *   1. Create a PriorityQueue with a comparator that orders by priority field
     *   2. Add all stored tasks to the queue
     *   3. Poll them out one at a time into a list (always gives smallest first)
     *
     * Time complexity: O(n log n) because inserting n items into a PriorityQueue
     * is O(log n) per item. This is the same as sorting a list - acceptable for
     * typical task list sizes.
     */
    public List<Task> getTasksByPriority() {
        // Comparator.comparingInt creates a comparator that compares tasks
        // by the integer returned from getPriority().
        // Lower priority numbers (1) come out first because PriorityQueue
        // gives you the minimum by default.
        PriorityQueue<Task> queue = new PriorityQueue<>(
                Comparator.comparingInt(Task::getPriority)
        );

        // Add all current tasks to the queue
        queue.addAll(tasks.values());

        // Drain the queue into a list: poll() removes and returns the minimum each time
        List<Task> sorted = new ArrayList<>();
        while (!queue.isEmpty()) {
            sorted.add(queue.poll());
        }

        return sorted;
    }

    /*
     * peekHighestPriorityTask() CS-499 ENHANCEMENT
     *
     * Returns the single most urgent task without removing it from storage.
     * Uses peek() on the PriorityQueue so nothing is removed from the queue,
     * and the original HashMap is completely untouched.
     *
     * Returns null if no tasks exist (empty check prevents a NullPointerException).
     */
    public Task peekHighestPriorityTask() {
        if (tasks.isEmpty()) return null;

        PriorityQueue<Task> queue = new PriorityQueue<>(
                Comparator.comparingInt(Task::getPriority)
        );
        queue.addAll(tasks.values());

        // peek() looks at the head without removing it
        return queue.peek();
    }

    // Prints all tasks to the console for debugging
    public void printAllTasks() {
        tasks.forEach((id, task) -> System.out.println(task));
    }

    // Prints tasks in priority order are useful for showing the enhancement in action
    public void printTasksByPriority() {
        System.out.println("Tasks sorted by priority:");
        getTasksByPriority().forEach(System.out::println);
    }

    /*
     * cloneTask(): creates a new Task with the same field values.
     * This is a shallow copy because Task only holds strings and an int,
     * so there are no nested objects to worry about.
     * Using this everywhere means the stored tasks are always independent
     * of whatever the caller is holding.
     */
    private Task cloneTask(Task task) {
        return new Task(task.getId(), task.getName(), task.getDescription(), task.getPriority());
    }
}
