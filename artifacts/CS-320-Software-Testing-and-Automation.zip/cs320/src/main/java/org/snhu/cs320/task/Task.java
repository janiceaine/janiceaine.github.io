/*
 * Task.java
 * Author: Janice Ainembabazi
 * CS-499 Capstone | SNHU 2026
 * Original artifact: CS-320 Software Testing and Automation, 2024
 *
 * This class represents a single task. It is similar in structure to
 * Contact.java from the same CS-320 project - both follow the same pattern
 * of validating fields in the constructor and keeping the ID immutable.
 *
 * CS-499 ENHANCEMENT:
 * For the capstone I added a priority field (1=high, 2=medium, 3=low).
 * This field is what makes the PriorityQueue in TaskService useful - without
 * a way to compare tasks, there would be no way to sort them by urgency.
 *
 * WHAT I LEARNED:
 * - How to think about what data a PriorityQueue needs to sort on.
 *   A PriorityQueue needs a way to compare two items. In Java you can
 *   do this with a Comparator. I use Comparator.comparingInt(Task::getPriority)
 *   in TaskService, which tells the queue to sort by the integer priority field.
 *   Lower numbers come out first, so priority 1 (high) beats priority 3 (low).
 *
 * - ValidationException from jakarta.validation is slightly different from
 *   IllegalArgumentException. I used it here because the Task project was
 *   already using the jakarta.validation library. Either works for this purpose.
 *
 * CS-320 CONCEPTS APPLIED:
 * - Immutable ID (final field, no setter for id)
 * - Input validation in the constructor and all setters
 * - toString() for readable debugging output
 */
package org.snhu.cs320.task;

import jakarta.validation.ValidationException;

public class Task {

    // id is final - cannot be changed after the task is created
    private final String id;

    // name and description can be updated, so they are not final
    private String name;
    private String description;

    // priority was added for the CS-499 enhancement.
    // 1 = high (most urgent), 2 = medium, 3 = low (least urgent).
    // This field drives the PriorityQueue ordering in TaskService.
    private int priority;

    /*
     * Constructor - creates a Task and validates all four fields.
     *
     * Field rules:
     *   id          - not null, max 10 characters
     *   name        - not null, max 20 characters
     *   description - not null, max 50 characters
     *   priority    - must be 1, 2, or 3 (anything else is rejected)
     */
    public Task(String id, String name, String description, int priority) {

        // Validate id null check always comes before length check to avoid
        // calling .length() on a null reference, which would throw NullPointerException
        if (id == null)
            throw new ValidationException("ID cannot be null");
        if (id.length() > 10)
            throw new ValidationException("ID cannot be longer than 10 characters");

        // Validate name
        if (name == null)
            throw new ValidationException("Name cannot be null");
        if (name.length() > 20)
            throw new ValidationException("Name cannot be longer than 20 characters");

        // Validate description
        if (description == null)
            throw new ValidationException("Description cannot be null");
        if (description.length() > 50)
            throw new ValidationException("Description cannot be longer than 50 characters");

        // Validate priority only 1, 2, or 3 are accepted values
        // This is an example of a range check, which I learned about in CS-405
        if (priority < 1 || priority > 3)
            throw new ValidationException("Priority must be 1 (high), 2 (medium), or 3 (low)");

        // All checks passed - assign the fields
        this.id          = id;
        this.name        = name;
        this.description = description;
        this.priority    = priority;
    }

    // Getters
    // getPriority() is especially important because TaskService's PriorityQueue
    // uses a method reference Task::getPriority as its Comparator
    public String getId()          { return id; }
    public String getName()        { return name; }
    public String getDescription() { return description; }
    public int    getPriority()    { return priority; }

    // Setters
    // There is no setId() because the id is final.
    // Each setter re-validates before updating the field.

    public void setName(String name) {
        if (name == null || name.length() > 20)
            throw new ValidationException("Name cannot be null or longer than 20 characters");
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50)
            throw new ValidationException("Description cannot be null or longer than 50 characters");
        this.description = description;
    }

    // Priority can be updated after creation, but still must be 1, 2, or 3
    public void setPriority(int priority) {
        if (priority < 1 || priority > 3)
            throw new ValidationException("Priority must be 1 (high), 2 (medium), or 3 (low)");
        this.priority = priority;
    }

    /*
     * toString() converts the priority number into a readable label.
     * I used a ternary expression here:
     *   priority == 1 ? "HIGH" : priority == 2 ? "MEDIUM" : "LOW"
     * This is a chained ternary. It checks priority == 1 first,
     * then priority == 2, and defaults to "LOW" for anything else (which
     * can only be 3 because of the validation above).
     */
    @Override
    public String toString() {
        String label = priority == 1 ? "HIGH" : priority == 2 ? "MEDIUM" : "LOW";
        return "Task [ID=" + id + ", Name=" + name
                + ", Description=" + description + ", Priority=" + label + "]";
    }
}
