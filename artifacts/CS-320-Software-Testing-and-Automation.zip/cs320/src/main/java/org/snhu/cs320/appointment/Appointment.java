/*
 * Appointment.java
 * Author: Janice Ainembabazi
 * CS-499 Capstone | SNHU 2026
 * Original artifact: CS-320 Software Testing and Automation, 2024
 *
 * This class represents a single scheduled appointment. It follows the same
 * structure as Contact and Task - validate in the constructor, keep the ID
 * immutable, and allow updates through validated setters.
 *
 * The unique thing about Appointment compared to the other models is that it
 * validates a Date field. The date must be in the future at the time the
 * appointment is created, which required calling new Date() to get the
 * current time and comparing it against the incoming value.
 *
 * WHAT I LEARNED:
 * - How to work with Java's Date class for basic date comparisons.
 *   Date.before(new Date()) returns true if the date is in the past.
 *   I used this for the "appointment must be in the future" requirement.
 *
 * - Why appointmentDate is final: once an appointment is scheduled for a
 *   specific date, changing that date would essentially be a different
 *   appointment. The original CS-320 requirement did not include a setDate()
 *   method, so I kept it immutable.
 *
 * - The data structure enhancement for this class lives in AppointmentService,
 *   not here. AppointmentService uses a TreeMap<Date, Appointment> to keep
 *   appointments in chronological order. The Date on this class is the key
 *   used in that TreeMap.
 *
 * CS-320 CONCEPTS APPLIED:
 * - Immutable fields (appointmentId and appointmentDate are final)
 * - Validation at construction time
 * - ValidationException from jakarta.validation for input errors
 */
package org.snhu.cs320.appointment;

import java.util.Date;

import jakarta.validation.ValidationException;

public class Appointment {

    // Both ID and date are final, neither should change after creation
    private final String appointmentId;
    private final Date   appointmentDate;

    // Description can be updated after creation
    private String description;

    /*
     * Constructor - validates all three fields before creating the appointment.
     *
     * Field rules:
     *   appointmentId   - not null, max 10 characters
     *   appointmentDate - not null, must be in the future
     *   description     - not null, max 50 characters
     */
    public Appointment(String appointmentId, Date appointmentDate, String description) {

        // Validate ID: same pattern as Contact and Task
        if (appointmentId == null || appointmentId.length() > 10)
            throw new ValidationException("Appointment ID cannot be null or longer than 10 characters.");

        // Validate date must not be null and must be after right now.
        // new Date() creates a Date object representing the current moment.
        // appointmentDate.before(new Date()) returns true if the date is in the past.
        if (appointmentDate == null || appointmentDate.before(new Date()))
            throw new ValidationException("Appointment date cannot be in the past or null.");

        // Validate description: same max length as Task description
        if (description == null || description.length() > 50)
            throw new ValidationException("Description cannot be null or longer than 50 characters.");

        this.appointmentId   = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description     = description;
    }

    // Getters 
    // getAppointmentDate() is especially important because AppointmentService
    // uses this date as the key in its TreeMap for chronological ordering
    public String getAppointmentId()   { return appointmentId; }
    public Date   getAppointmentDate() { return appointmentDate; }
    public String getDescription()     { return description; }

    // Setter 
    // Only description has a setter. There is no setAppointmentId() or
    // setAppointmentDate() because those fields are final.

    public void setDescription(String description) {
        if (description == null || description.length() > 50)
            throw new ValidationException("Description cannot be null or longer than 50 characters.");
        this.description = description;
    }

    /*
     * toString() for readable output when printing or debugging.
     * Showing the date in full makes it easier to verify chronological
     * ordering when testing the TreeMap in AppointmentService.
     */
    @Override
    public String toString() {
        return "Appointment [ID=" + appointmentId + ", Date=" + appointmentDate
                + ", Description=" + description + "]";
    }
}
