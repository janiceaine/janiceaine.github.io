/*
 * Main.java
 * Author: Janice Ainembabazi
 * CS-499 Capstone | SNHU 2026
 *
 * This class runs a demonstration of the CS-499 algorithm and data structure
 * enhancements so you can see the sorting behavior in action at runtime.
 *
 * WHAT THIS SHOWS:
 * - TaskService.getTasksByPriority() using a PriorityQueue:
 *   Tasks are added in random priority order, and the output shows them
 *   sorted from most urgent (HIGH) to least urgent (LOW).
 *
 * - AppointmentService.getAppointmentsSortedByDate() using a TreeMap:
 *   Appointments are added in random date order, and the output shows them
 *   in chronological order (earliest first).
 *
 * - AppointmentService.getNextAppointment() using TreeMap.firstEntry():
 *   Shows the earliest upcoming appointment, then shows how the result
 *   changes after deleting that appointment.
 *
 * TO RUN:
 *   mvn exec:java         (runs this class)
 *   mvn test              (runs all JUnit tests)
 */
package org.snhu.cs320;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.snhu.cs320.appointment.Appointment;
import org.snhu.cs320.appointment.AppointmentService;
import org.snhu.cs320.task.Task;
import org.snhu.cs320.task.TaskAlreadyExistsException;
import org.snhu.cs320.task.TaskService;

public class Main {

    public static void main(String[] args) {

        // SimpleDateFormat formats Date objects into readable strings like "2026-05-25 08:00"
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm");

        System.out.println("=".repeat(55));
        System.out.println("  CS-499 Enhancement: Algorithms & Data Structures");
        System.out.println("=".repeat(55));

        // TASK PRIORITY QUEUE DEMO 
        // Shows that getTasksByPriority() sorts by priority value,
        // not by insertion order. Tasks are added with LOW priority first
        // and HIGH priority last to make this clear.
        System.out.println("\n*** TaskService: PriorityQueue Demo ***\n");

        TaskService taskService = new TaskService();

        try {
            // Adding in reverse priority order intentionally
            taskService.addTask(new Task("T003", "Update docs",  "Refresh readme file",       3)); // LOW first
            taskService.addTask(new Task("T002", "Write tests",  "Add unit test coverage",    2)); // MEDIUM
            taskService.addTask(new Task("T004", "Code review",  "Review pull requests",      2)); // MEDIUM
            taskService.addTask(new Task("T005", "Deploy build", "Push to staging server",    1)); // HIGH
            taskService.addTask(new Task("T001", "Fix bug",      "Critical production issue", 1)); // HIGH last

            System.out.println("Tasks sorted by priority (HIGH first, LOW last):");
            List<Task> sorted = taskService.getTasksByPriority();
            for (Task t : sorted) {
                // Convert the priority number to a readable label for display
                String label = t.getPriority() == 1 ? "HIGH  "
                             : t.getPriority() == 2 ? "MEDIUM"
                             : "LOW   ";
                System.out.println("  [" + label + "]  " + t.getName()
                        + "  -  " + t.getDescription());
            }

            // Show the most urgent task using peekHighestPriorityTask()
            Task nextTask = taskService.peekHighestPriorityTask();
            System.out.println("\nMost urgent task right now: " + nextTask.getName()
                    + " (Priority: HIGH)");

        } catch (TaskAlreadyExistsException e) {
            System.out.println("Error: " + e.getMessage());
        }

        // APPOINTMENT TREEMAP DEMO 
        // Shows that getAppointmentsSortedByDate() returns appointments in
        // chronological order regardless of which order they were added in.
        System.out.println("\n*** AppointmentService: TreeMap Demo ***\n");

        AppointmentService apptService = new AppointmentService();
        long now = System.currentTimeMillis();

        // Adding in reverse date order intentionally
        apptService.addAppointment(new Appointment("A003", new Date(now + 2_592_000_000L), "Tech conference")); // furthest
        apptService.addAppointment(new Appointment("A001", new Date(now + 86_400_000L),    "Dentist checkup")); // nearest
        apptService.addAppointment(new Appointment("A004", new Date(now + 172_800_000L),   "Job interview"));   // second nearest
        apptService.addAppointment(new Appointment("A002", new Date(now + 604_800_000L),   "Annual physical")); // middle

        System.out.println("\nAppointments in chronological order:");
        List<Appointment> sortedAppts = apptService.getAppointmentsSortedByDate();
        for (Appointment a : sortedAppts) {
            System.out.println("  " + fmt.format(a.getAppointmentDate())
                    + "  ->  " + a.getDescription());
        }

        // Show getNextAppointment() using TreeMap.firstEntry()
        Appointment nextAppt = apptService.getNextAppointment();
        System.out.println("\nNext upcoming appointment: " + nextAppt.getDescription()
                + "  on  " + fmt.format(nextAppt.getAppointmentDate()));

        // Delete the nearest appointment and show that the TreeMap updates correctly
        System.out.println("\nDeleting nearest appointment (Dentist)...");
        apptService.deleteAppointment("A001");

        Appointment newNext = apptService.getNextAppointment();
        System.out.println("Next appointment is now: " + newNext.getDescription()
                + "  on  " + fmt.format(newNext.getAppointmentDate()));

        System.out.println("\n" + "=".repeat(55));
        System.out.println("  Run 'mvn test' to see all JUnit test results.");
        System.out.println("=".repeat(55));
    }
}
