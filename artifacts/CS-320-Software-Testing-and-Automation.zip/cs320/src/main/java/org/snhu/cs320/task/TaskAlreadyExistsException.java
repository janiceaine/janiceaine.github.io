/*
 * TaskAlreadyExistsException.java
 * Author: Janice Ainembabazi
 * CS-499 Capstone | SNHU 2026
 * Original artifact: CS-320 Software Testing and Automation, 2024
 *
 * This is a custom checked exception that gets thrown when someone tries
 * to add a task whose ID already exists in TaskService.
 *
 * WHAT I LEARNED:
 * - The difference between checked and unchecked exceptions.
 *   This extends Exception (checked), which means any method that calls
 *   addTask() must either catch this exception or declare it with throws.
 *   That forces the caller to think about and handle the duplicate case.
 *
 * - Why create a custom exception instead of using a generic one?
 *   Using TaskAlreadyExistsException makes the error message clearer and
 *   lets tests use assertThrows(TaskAlreadyExistsException.class, ...) to
 *   verify exactly the right kind of error was thrown. A generic Exception
 *   would make tests less precise.
 *
 * CS-320 CONCEPTS APPLIED:
 * - Custom exceptions for meaningful error handling
 * - Passing a message string to the parent Exception constructor so the
 *   error message tells you which task ID caused the problem
 */
package org.snhu.cs320.task;

public class TaskAlreadyExistsException extends Exception {

    /*
     * Constructor passes the message up to the Exception parent class.
     * The message can be retrieved later with getMessage() which is
     * useful when logging errors or displaying them to a user.
     */
    public TaskAlreadyExistsException(String message) {
        super(message);
    }
}
