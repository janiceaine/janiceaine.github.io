/*
 * TaskServiceTest.java
 * Author: Janice Ainembabazi
 * CS-499 Capstone | SNHU 2026
 * Original artifact: CS-320 Software Testing and Automation, 2024
 *
 * Unit tests for TaskService including the PriorityQueue methods
 * added as part of the CS-499 enhancement.
 *
 * WHAT I LEARNED:
 * - How to test a sorted data structure.
 *   To really test that getTasksByPriority() sorts correctly, I intentionally
 *   add tasks in the WRONG order (low first, high last) and then verify the
 *   output list has them in the correct order. If I had added them in priority
 *   order already, I might not catch a bug where the method returns them in
 *   insertion order instead of sorted order.
 *
 * - The difference between testing peek vs poll behavior.
 *   peekHighestPriorityTask() should NOT remove anything from storage.
 *   I test this by calling peek and then checking that the task count
 *   in getTasks() is unchanged. This verifies that peek is truly non-destructive.
 *
 * - Testing edge cases for the empty collection.
 *   What happens if you call getTasksByPriority() or peekHighestPriorityTask()
 *   when no tasks have been added? These methods should return an empty list
 *   and null respectively, not throw an exception. Testing empty cases is
 *   something I learned is important in CS-320.
 *
 * CS-499 CONCEPTS TESTED:
 * - PriorityQueue ordering (not insertion order)
 * - peek() does not remove from underlying storage
 * - Sorting with tasks of equal priority (both get included)
 */
package org.snhu.cs320.task;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import jakarta.validation.ValidationException;

public class TaskServiceTest {

    private TaskService taskService;
    private Task highTask;
    private Task medTask;
    private Task lowTask;

    @BeforeEach
    void setUp() {
        taskService = new TaskService();
        // Three tasks at different priority levels for sorting tests
        highTask = new Task("T001", "Fix bug",     "Critical production issue", 1);
        medTask  = new Task("T002", "Write tests", "Add unit test coverage",   2);
        lowTask  = new Task("T003", "Update docs", "Refresh readme file",      3);
    }

    // ── Original operation tests ──────────────────────────────────────────────

    @Test
    public void testAddTaskSucceeds() throws TaskAlreadyExistsException {
        taskService.addTask(highTask);
        // Check count and verify the stored data matches what was added
        Assertions.assertEquals(1, taskService.getTasks().size());
        Assertions.assertEquals("Fix bug", taskService.getTasks().get("T001").getName());
    }

    @Test
    public void testAddDuplicateIdThrows() throws TaskAlreadyExistsException {
        taskService.addTask(highTask);
        // Second add with the same ID should throw our custom exception
        Assertions.assertThrows(TaskAlreadyExistsException.class,
                () -> taskService.addTask(highTask));
    }

    @Test
    public void testDeleteTaskSucceeds() throws TaskAlreadyExistsException {
        taskService.addTask(highTask);
        taskService.deleteTaskById("T001");
        // After deletion the task should not be found
        Assertions.assertNull(taskService.getTasks().get("T001"));
    }

    @Test
    public void testDeleteNonExistentDoesNotThrow() {
        // Deleting an ID that never existed should not cause an error
        Assertions.assertDoesNotThrow(() -> taskService.deleteTaskById("NOTEXIST"));
    }

    @Test
    public void testUpdateTaskName() throws TaskAlreadyExistsException {
        taskService.addTask(highTask);
        highTask.setName("Patched bug");
        taskService.updateTask(highTask);
        // Verify the new name was stored
        Assertions.assertEquals("Patched bug", taskService.getTasks().get("T001").getName());
    }

    @Test
    public void testUpdateTaskDescription() throws TaskAlreadyExistsException {
        taskService.addTask(highTask);
        highTask.setDescription("Bug resolved in v2.1");
        taskService.updateTask(highTask);
        Assertions.assertEquals("Bug resolved in v2.1", taskService.getTasks().get("T001").getDescription());
    }

    @Test
    public void testNullIdThrows() {
        Assertions.assertThrows(ValidationException.class,
                () -> new Task(null, "Fix bug", "Description", 1));
    }

    @Test
    public void testIdTooLongThrows() {
        Assertions.assertThrows(ValidationException.class,
                () -> new Task("12345678901", "Fix bug", "Description", 1));
    }

    // PriorityQueue tests (CS-499 enhancement) 

    @Test
    public void testGetTasksByPriorityReturnsHighFirst() throws TaskAlreadyExistsException {
        // Add in reverse order so sorting is actually being tested
        // If the method just returned insertion order, this test would fail
        taskService.addTask(lowTask);    // added first
        taskService.addTask(highTask);   // added second
        taskService.addTask(medTask);    // added third

        List<Task> sorted = taskService.getTasksByPriority();

        // First item out should be priority 1 regardless of insertion order
        Assertions.assertEquals(1, sorted.get(0).getPriority());
        Assertions.assertEquals(2, sorted.get(1).getPriority());
        Assertions.assertEquals(3, sorted.get(2).getPriority());
    }

    @Test
    public void testGetTasksByPriorityReturnsAllTasks() throws TaskAlreadyExistsException {
        taskService.addTask(highTask);
        taskService.addTask(medTask);
        taskService.addTask(lowTask);
        // All three tasks should be in the result, none should be dropped
        Assertions.assertEquals(3, taskService.getTasksByPriority().size());
    }

    @Test
    public void testGetTasksByPriorityEmptyReturnsEmptyList() {
        // Empty service should return an empty list, not null or an exception
        List<Task> result = taskService.getTasksByPriority();
        Assertions.assertNotNull(result);
        Assertions.assertEquals(0, result.size());
    }

    @Test
    public void testPeekHighestPriorityReturnsCorrectTask() throws TaskAlreadyExistsException {
        // Add medium and low before high to verify peek finds the right one
        taskService.addTask(medTask);
        taskService.addTask(lowTask);
        taskService.addTask(highTask);

        Task highest = taskService.peekHighestPriorityTask();
        Assertions.assertNotNull(highest);
        // Should always be priority 1 regardless of insertion order
        Assertions.assertEquals(1, highest.getPriority());
    }

    @Test
    public void testPeekDoesNotRemoveFromStorage() throws TaskAlreadyExistsException {
        taskService.addTask(highTask);
        taskService.addTask(medTask);

        // Calling peek should not reduce the number of tasks stored
        taskService.peekHighestPriorityTask();
        Assertions.assertEquals(2, taskService.getTasks().size());
    }

    @Test
    public void testPeekReturnsNullWhenEmpty() {
        // No tasks added, peek should return null not throw NullPointerException
        Assertions.assertNull(taskService.peekHighestPriorityTask());
    }

    @Test
    public void testTasksWithSamePriorityBothAppearInResult() throws TaskAlreadyExistsException {
        // Two tasks both at priority 2 should both appear in the sorted list
        Task med2 = new Task("T004", "Code review", "Review pull requests", 2);
        taskService.addTask(medTask);
        taskService.addTask(med2);

        List<Task> sorted = taskService.getTasksByPriority();
        Assertions.assertEquals(2, sorted.size());
        // Both should have priority 2
        Assertions.assertEquals(2, sorted.get(0).getPriority());
        Assertions.assertEquals(2, sorted.get(1).getPriority());
    }
}
