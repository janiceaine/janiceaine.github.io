/*
 * AppointmentServiceTest.java
 * Author: Janice Ainembabazi
 * CS-499 Capstone | SNHU 2026
 * Original artifact: CS-320 Software Testing and Automation, 2024
 *
 * Unit tests for AppointmentService including the TreeMap methods
 * added as part of the CS-499 enhancement.
 *
 * WHAT I LEARNED:
 * - How to test that a sorted data structure actually sorts.
 *   Just like with the PriorityQueue tests in TaskServiceTest, I add
 *   appointments in the WRONG date order (far future first, near future last)
 *   and then verify the sorted output has them in the correct order.
 *   This proves the TreeMap is doing real sorting, not just returning
 *   items in insertion order.
 *
 * - How to test that two data structures stay in sync.
 *   The deleteRemovesFromBothStructures test adds two appointments, deletes
 *   one, and then checks BOTH that the HashMap no longer has it AND that
 *   the TreeMap's next appointment is now the remaining one. This covers
 *   the scenario where a bug could delete from one structure but not the other.
 *
 * - Testing getNextAppointment() as a pure peek operation.
 *   After calling getNextAppointment() I check that the appointment count
 *   has not changed. This confirms that firstEntry() in the TreeMap is truly
 *   non-destructive and does not remove the appointment from storage.
 *
 * - The three dates in setUp() use different offsets from currentTimeMillis()
 *   so they are clearly in different order: 1M ms < 10M ms < 100M ms.
 *   Using System.currentTimeMillis() instead of hardcoded dates means the
 *   tests still work correctly no matter when they are run.
 */
package org.snhu.cs320.appointment;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import jakarta.validation.ValidationException;

public class AppointmentServiceTest {

    private AppointmentService apptService;

    // Three appointments with clearly different future dates
    private Appointment nearAppt;   // soonest - 1,000,000 ms from now
    private Appointment midAppt;    // middle  - 10,000,000 ms from now
    private Appointment farAppt;    // furthest - 100,000,000 ms from now

    @BeforeEach
    public void setUp() {
        apptService = new AppointmentService();
        long now = System.currentTimeMillis();
        nearAppt = new Appointment("A001", new Date(now + 1_000_000),   "Dentist");
        midAppt  = new Appointment("A002", new Date(now + 10_000_000),  "Doctor");
        farAppt  = new Appointment("A003", new Date(now + 100_000_000), "Conference");
    }

    // Original operation tests

    @Test
    public void testAddAppointmentSucceeds() {
        apptService.addAppointment(nearAppt);
        Assertions.assertEquals(1, apptService.getAppointments().size());
        Assertions.assertEquals(nearAppt, apptService.getAppointments().get("A001"));
    }

    @Test
    public void testAddDuplicateIdThrows() {
        apptService.addAppointment(nearAppt);
        // Second add with same ID should throw ValidationException
        Assertions.assertThrows(ValidationException.class,
                () -> apptService.addAppointment(nearAppt));
    }

    @Test
    public void testDeleteAppointmentSucceeds() {
        apptService.addAppointment(nearAppt);
        apptService.deleteAppointment("A001");
        Assertions.assertEquals(0, apptService.getAppointments().size());
    }

    @Test
    public void testDeleteNonExistentDoesNotThrow() {
        // Deleting an ID that was never added should not cause an error
        Assertions.assertDoesNotThrow(() -> apptService.deleteAppointment("NOTEXIST"));
    }

    @Test
    public void testGetAppointmentsReturnsAllAdded() {
        apptService.addAppointment(nearAppt);
        apptService.addAppointment(midAppt);
        Assertions.assertEquals(2, apptService.getAppointments().size());
    }

    // TreeMap tests (CS-499 enhancement)
    @Test
    public void testGetSortedByDateReturnsChronologicalOrder() {
        // Add in REVERSE date order to prove TreeMap sorts, not just insertion order
        apptService.addAppointment(farAppt);   // far added first
        apptService.addAppointment(nearAppt);  // near added second
        apptService.addAppointment(midAppt);   // mid added third

        List<Appointment> sorted = apptService.getAppointmentsSortedByDate();

        // Despite insertion order, the earliest date should always come first
        Assertions.assertEquals("A001", sorted.get(0).getAppointmentId()); // near
        Assertions.assertEquals("A002", sorted.get(1).getAppointmentId()); // mid
        Assertions.assertEquals("A003", sorted.get(2).getAppointmentId()); // far
    }

    @Test
    public void testGetSortedByDateReturnsAllAppointments() {
        apptService.addAppointment(nearAppt);
        apptService.addAppointment(midAppt);
        apptService.addAppointment(farAppt);
        // All three should appear, none should be dropped
        Assertions.assertEquals(3, apptService.getAppointmentsSortedByDate().size());
    }

    @Test
    public void testGetSortedByDateEmptyReturnsEmptyList() {
        // Empty service should return empty list, not null or an exception
        List<Appointment> result = apptService.getAppointmentsSortedByDate();
        Assertions.assertNotNull(result);
        Assertions.assertEquals(0, result.size());
    }

    @Test
    public void testGetNextAppointmentReturnsEarliest() {
        // Add far first, then near, so insertion order is wrong
        // TreeMap should still return the earliest date
        apptService.addAppointment(farAppt);
        apptService.addAppointment(nearAppt);
        apptService.addAppointment(midAppt);

        Appointment next = apptService.getNextAppointment();
        Assertions.assertNotNull(next);
        Assertions.assertEquals("A001", next.getAppointmentId());
    }

    @Test
    public void testGetNextAppointmentReturnsNullWhenEmpty() {
        // No appointments added, should return null not throw
        Assertions.assertNull(apptService.getNextAppointment());
    }

    @Test
    public void testGetNextAppointmentDoesNotRemoveFromStorage() {
        apptService.addAppointment(nearAppt);
        apptService.addAppointment(midAppt);

        // Calling getNextAppointment() is a peek operation, should not remove anything
        apptService.getNextAppointment();
        Assertions.assertEquals(2, apptService.getAppointments().size());
    }

    @Test
    public void testDeleteRemovesFromBothHashMapAndTreeMap() {
        apptService.addAppointment(nearAppt);
        apptService.addAppointment(midAppt);

        // Delete the nearest appointment
        apptService.deleteAppointment("A001");

        // Check that HashMap no longer has it
        Assertions.assertFalse(apptService.getAppointments().containsKey("A001"));

        // Check that TreeMap was also updated, next appointment should now be midAppt
        Appointment next = apptService.getNextAppointment();
        Assertions.assertNotNull(next);
        Assertions.assertEquals("A002", next.getAppointmentId());
    }

    @Test
    public void testPrintAllAppointmentsDoesNotThrow() {
        apptService.addAppointment(nearAppt);
        apptService.addAppointment(farAppt);
        // Just verify it runs without error, output goes to console
        Assertions.assertDoesNotThrow(() -> apptService.printAllAppointments());
    }
}
