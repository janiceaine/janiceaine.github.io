/*
 * ContactTest.java
 * Author: Janice Ainembabazi
 * CS-499 Capstone | SNHU 2026
 * Original artifact: CS-320 Software Testing and Automation, 2024
 *
 * Unit tests for the Contact class using JUnit 5.
 *
 * WHAT I LEARNED:
 * - The difference between positive tests (sunny day) and negative tests
 *   (rainy day). Positive tests verify the code works correctly with valid input.
 *   Negative tests verify that the code correctly rejects bad input.
 *   In CS-320 I learned that both types are equally important.
 *
 * - @BeforeEach runs the setUp() method before every single test.
 *   This means each test gets a fresh Contact object to work with.
 *   Tests should not depend on each other's side effects, and @BeforeEach
 *   helps enforce that.
 *
 * - assertThrows() checks that a specific exception is thrown when expected.
 *   It takes the exception class and a lambda that should trigger the exception.
 *   If the exception is NOT thrown, the test fails.
 *
 * - assertEquals() checks that two values are equal.
 *   assertTrue() and assertFalse() check boolean conditions.
 *   assertNotNull() checks that an object is not null.
 *
 * CS-320 CONCEPTS APPLIED:
 * - Testing all boundaries: null inputs, values exactly at the limit,
 *   values one over the limit
 * - One assertion focus per test so a failing test tells you exactly what broke
 */
package org.snhu.cs320.contact;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactTest {

    // Declared at class level so setUp() and tests can both access it
    private Contact contact;

    /*
     * @BeforeEach - runs before each test method.
     * Creates a fresh Contact with valid data so every test starts
     * from the same known state.
     */
    @BeforeEach
    public void setUp() {
        contact = new Contact("C001", "Jane", "Doe", "5551234567", "123 Main St");
    }

    // ── Positive tests ────────────────────────────────────────────────────────

    @Test
    public void testValidContactCreation() {
        // Verify that a valid contact is created without throwing
        Assertions.assertNotNull(contact);
    }

    @Test
    public void testGetContactId() {
        Assertions.assertEquals("C001", contact.getContactId());
    }

    @Test
    public void testGetFirstName() {
        Assertions.assertEquals("Jane", contact.getFirstName());
    }

    @Test
    public void testGetLastName() {
        Assertions.assertEquals("Doe", contact.getLastName());
    }

    @Test
    public void testGetPhoneNumber() {
        Assertions.assertEquals("5551234567", contact.getPhoneNumber());
    }

    @Test
    public void testGetAddress() {
        Assertions.assertEquals("123 Main St", contact.getAddress());
    }

    @Test
    public void testSetFirstName() {
        contact.setFirstName("Mary");
        Assertions.assertEquals("Mary", contact.getFirstName());
    }

    @Test
    public void testSetLastName() {
        contact.setLastName("Smith");
        Assertions.assertEquals("Smith", contact.getLastName());
    }

    @Test
    public void testSetPhoneNumber() {
        contact.setPhoneNumber("9998887777");
        Assertions.assertEquals("9998887777", contact.getPhoneNumber());
    }

    @Test
    public void testSetAddress() {
        contact.setAddress("456 Oak Ave");
        Assertions.assertEquals("456 Oak Ave", contact.getAddress());
    }

    // Negative tests 
    // These tests verify that illegal inputs are rejected with the right exception.
    // assertThrows() takes the expected exception class and a lambda.
    // The test passes only if that specific exception is thrown inside the lambda.

    @Test
    public void testNullIdThrows() {
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> new Contact(null, "Jane", "Doe", "5551234567", "123 Main St"));
    }

    @Test
    public void testIdTooLongThrows() {
        // "12345678901" is 11 characters - one over the 10 character limit
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> new Contact("12345678901", "Jane", "Doe", "5551234567", "123 Main St"));
    }

    @Test
    public void testNullFirstNameThrows() {
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> new Contact("C001", null, "Doe", "5551234567", "123 Main St"));
    }

    @Test
    public void testFirstNameTooLongThrows() {
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> new Contact("C001", "JaneIsWayTooLong", "Doe", "5551234567", "123 Main St"));
    }

    @Test
    public void testPhoneNumberTooShortThrows() {
        // Phone must be exactly 10 - 9 digits should fail
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> new Contact("C001", "Jane", "Doe", "123456789", "123 Main St"));
    }

    @Test
    public void testPhoneNumberTooLongThrows() {
        // 11 digits should also fail
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> new Contact("C001", "Jane", "Doe", "12345678901", "123 Main St"));
    }

    @Test
    public void testAddressTooLongThrows() {
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> new Contact("C001", "Jane", "Doe", "5551234567",
                        "This address is way too long to be accepted here"));
    }
}
