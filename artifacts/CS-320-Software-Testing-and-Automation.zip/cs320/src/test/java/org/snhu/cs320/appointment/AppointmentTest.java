/*
 * AppointmentTest.java
 * Author: Janice Ainembabazi
 * CS-499 Capstone | SNHU 2026
 * Original artifact: CS-320 Software Testing and Automation, 2024
 *
 * Unit tests for the Appointment model.
 *
 * WHAT I LEARNED:
 * - How to test date-based validation.
 *   To test that a past date fails, I create a date by subtracting from
 *   System.currentTimeMillis(). To test that a future date works, I add
 *   to it. Using currentTimeMillis() instead of a hardcoded date means
 *   the tests still pass no matter when they are run.
 *
 * - Why the appointmentDate field is final and has no setter.
 *   The CS-320 requirements did not include an "update appointment date"
 *   requirement. Making it final enforces that constraint in the code.
 *   If a date needs to change, the correct approach is to delete the old
 *   appointment and create a new one with the correct date.
 *
 * - The setDescription() setter still needs its own test even though
 *   the constructor already validates description. The setter is a separate
 *   code path and could have a bug even if the constructor is correct.
 */
package org.snhu.cs320.appointment;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import jakarta.validation.ValidationException;

public class AppointmentTest {

    private String validId;
    private Date   futureDate;
    private String validDesc;

    @BeforeEach
    public void setUp() {
        validId    = "A001";
        // currentTimeMillis() gives the current time in milliseconds.
        // Adding 1,000,000 ms (~16 minutes) makes it a future date.
        futureDate = new Date(System.currentTimeMillis() + 1_000_000);
        validDesc  = "Dentist checkup";
    }

    // ── Positive tests ────────────────────────────────────────────────────────

    @Test
    public void testValidAppointmentCreation() {
        Appointment a = new Appointment(validId, futureDate, validDesc);
        Assertions.assertNotNull(a);
        Assertions.assertEquals(validId,   a.getAppointmentId());
        Assertions.assertEquals(futureDate, a.getAppointmentDate());
        Assertions.assertEquals(validDesc,  a.getDescription());
    }

    @Test
    public void testSetDescription() {
        Appointment a = new Appointment(validId, futureDate, validDesc);
        a.setDescription("Updated appointment details");
        Assertions.assertEquals("Updated appointment details", a.getDescription());
    }

    // ── Negative tests ────────────────────────────────────────────────────────

    @Test
    public void testNullIdThrows() {
        Assertions.assertThrows(ValidationException.class,
                () -> new Appointment(null, futureDate, validDesc));
    }

    @Test
    public void testIdTooLongThrows() {
        // 11 characters - one over the 10 character limit
        Assertions.assertThrows(ValidationException.class,
                () -> new Appointment("12345678901", futureDate, validDesc));
    }

    @Test
    public void testPastDateThrows() {
        // Subtracting from currentTimeMillis() creates a date in the past
        Date pastDate = new Date(System.currentTimeMillis() - 1_000_000);
        Assertions.assertThrows(ValidationException.class,
                () -> new Appointment(validId, pastDate, validDesc));
    }

    @Test
    public void testNullDateThrows() {
        Assertions.assertThrows(ValidationException.class,
                () -> new Appointment(validId, null, validDesc));
    }

    @Test
    public void testNullDescriptionThrows() {
        Assertions.assertThrows(ValidationException.class,
                () -> new Appointment(validId, futureDate, null));
    }

    @Test
    public void testDescriptionTooLongThrows() {
        // This string is over 50 characters and should be rejected
        Assertions.assertThrows(ValidationException.class,
                () -> new Appointment(validId, futureDate,
                        "This description is way too long and should not be accepted"));
    }

    @Test
    public void testSetDescriptionTooLongThrows() {
        // The setter should apply the same validation as the constructor
        Appointment a = new Appointment(validId, futureDate, validDesc);
        Assertions.assertThrows(ValidationException.class,
                () -> a.setDescription("This description is way too long and should fail here"));
    }
}
