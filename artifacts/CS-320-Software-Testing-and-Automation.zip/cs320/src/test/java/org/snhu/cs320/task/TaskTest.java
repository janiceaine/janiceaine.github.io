/*
 * TaskTest.java
 * Author: Janice Ainembabazi
 * CS-499 Capstone | SNHU 2026
 * Original artifact: CS-320 Software Testing and Automation, 2024
 *
 * Unit tests for the Task model including the new priority field
 * added as part of the CS-499 enhancement.
 *
 * WHAT I LEARNED:
 * - Boundary testing: I do not just test that priority 1, 2, and 3 work.
 *   I also test that 0, 4, and -1 fail. These boundary cases are where bugs
 *   most commonly hide. In CS-320 I learned that testing at the edges of
 *   valid input ranges is just as important as testing in the middle.
 *
 * - Testing the toString() output: I check that the toString() method
 *   includes the word "HIGH", "MEDIUM", or "LOW" depending on the priority.
 *   This verifies that the priority label conversion is working correctly
 *   and that the output is human-readable, not just a number.
 *
 * - Why I test both the constructor and the setter for priority:
 *   The constructor and setter have the same validation logic, but they
 *   are separate code paths. Testing both makes sure validation was not
 *   accidentally left out of one of them.
 */
package org.snhu.cs320.task;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import jakarta.validation.ValidationException;

public class TaskTest {

    private Task task;

    @BeforeEach
    public void setUp() {
        // High priority task (priority=1) as the default test object
        task = new Task("T001", "Fix bug", "Critical production issue", 1);
    }

    // ── Original field tests ──────────────────────────────────────────────────

    @Test
    public void testGetId() {
        Assertions.assertEquals("T001", task.getId());
    }

    @Test
    public void testGetName() {
        Assertions.assertEquals("Fix bug", task.getName());
    }

    @Test
    public void testGetDescription() {
        Assertions.assertEquals("Critical production issue", task.getDescription());
    }

    @Test
    public void testSetName() {
        task.setName("Patched bug");
        Assertions.assertEquals("Patched bug", task.getName());
    }

    @Test
    public void testSetDescription() {
        task.setDescription("Bug resolved in v2.1");
        Assertions.assertEquals("Bug resolved in v2.1", task.getDescription());
    }

    // ── Null and length validation tests ─────────────────────────────────────

    @Test
    public void testNullIdThrows() {
        Assertions.assertThrows(ValidationException.class,
                () -> new Task(null, "Fix bug", "Description", 1));
    }

    @Test
    public void testIdTooLongThrows() {
        Assertions.assertThrows(ValidationException.class,
                () -> new Task("12345678901", "Fix bug", "Description", 1));
    }

    @Test
    public void testNullNameThrows() {
        Assertions.assertThrows(ValidationException.class,
                () -> new Task("T001", null, "Description", 1));
    }

    @Test
    public void testNameTooLongThrows() {
        // 21 characters - one over the 20 character limit
        Assertions.assertThrows(ValidationException.class,
                () -> new Task("T001", "this-name-is-too-long", "Description", 1));
    }

    @Test
    public void testNullDescriptionThrows() {
        Assertions.assertThrows(ValidationException.class,
                () -> new Task("T001", "Fix bug", null, 1));
    }

    @Test
    public void testDescriptionTooLongThrows() {
        Assertions.assertThrows(ValidationException.class,
                () -> new Task("T001", "Fix bug",
                        "this description is way too long to be valid here today", 1));
    }

    // ── Priority field tests (CS-499 enhancement) ─────────────────────────────

    @Test
    public void testGetPriorityReturnsCorrectValue() {
        // Priority was set to 1 in setUp(): verify the getter returns it correctly
        Assertions.assertEquals(1, task.getPriority());
    }

    @Test
    public void testPriorityTwoIsValid() {
        // Medium priority task should be created without throwing
        Task medTask = new Task("T002", "Write tests", "Add coverage", 2);
        Assertions.assertEquals(2, medTask.getPriority());
    }

    @Test
    public void testPriorityThreeIsValid() {
        // Low priority task should also be created without throwing
        Task lowTask = new Task("T003", "Update docs", "Refresh readme", 3);
        Assertions.assertEquals(3, lowTask.getPriority());
    }

    @Test
    public void testSetPriorityToMedium() {
        // Update from high (1) to medium (2) and verify
        task.setPriority(2);
        Assertions.assertEquals(2, task.getPriority());
    }

    @Test
    public void testSetPriorityToLow() {
        task.setPriority(3);
        Assertions.assertEquals(3, task.getPriority());
    }

    @Test
    public void testPriorityZeroThrows() {
        // 0 is below the valid range (should be rejected)
        Assertions.assertThrows(ValidationException.class,
                () -> new Task("T001", "Fix bug", "Description", 0));
    }

    @Test
    public void testPriorityFourThrows() {
        // 4 is above the valid range (should be rejected)
        Assertions.assertThrows(ValidationException.class,
                () -> new Task("T001", "Fix bug", "Description", 4));
    }

    @Test
    public void testNegativePriorityThrows() {
        // Negative values should also be rejected
        Assertions.assertThrows(ValidationException.class,
                () -> new Task("T001", "Fix bug", "Description", -1));
    }

    @Test
    public void testSetPriorityInvalidThrows() {
        // The setter should validate the same way the constructor does
        Assertions.assertThrows(ValidationException.class, () -> task.setPriority(5));
    }

    @Test
    public void testToStringShowsHighLabel() {
        // Priority 1 should show "HIGH" in the string output, not just "1"
        Assertions.assertTrue(task.toString().contains("HIGH"));
    }

    @Test
    public void testToStringShowsMediumLabel() {
        Task med = new Task("T002", "Write tests", "Add coverage", 2);
        Assertions.assertTrue(med.toString().contains("MEDIUM"));
    }

    @Test
    public void testToStringShowsLowLabel() {
        Task low = new Task("T003", "Update docs", "Refresh readme", 3);
        Assertions.assertTrue(low.toString().contains("LOW"));
    }
}
