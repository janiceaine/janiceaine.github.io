/*
 * ContactServiceTest.java
 * Author: Janice Ainembabazi
 * CS-499 Capstone | SNHU 2026
 * Original artifact: CS-320 Software Testing and Automation, 2024
 *
 * Unit tests for ContactService.
 *
 * WHAT I LEARNED:
 * - Testing the service layer separately from the model layer.
 *   ContactTest already tests that Contact validates its fields correctly.
 *   ContactServiceTest focuses on the collection behavior: can I add, delete,
 *   and update contacts through the service? This separation makes tests easier
 *   to read and debug because each test file has one clear responsibility.
 *
 * - Testing return values to verify success and failure.
 *   addContact() returns a boolean. I test both the true case (new contact)
 *   and the false case (duplicate ID). This is important because both paths
 *   in the code need to be exercised to get good test coverage.
 *
 * - Checking state after an operation.
 *   After calling updateContactFirstName(), I use getContacts() to retrieve
 *   the stored contact and verify the name actually changed. Just checking
 *   the return value of the update method is not enough - I want to confirm
 *   the change was persisted correctly.
 */
package org.snhu.cs320.contact;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private ContactService contactService;
    private Contact contact;

    @BeforeEach
    public void setUp() {
        // Fresh service and contact before each test, no shared state between tests
        contactService = new ContactService();
        contact = new Contact("C001", "Jane", "Doe", "5551234567", "123 Main St");
    }

    // Add tests

    @Test
    public void testAddContactSucceeds() {
        // Adding a new contact should return true and increase the count
        Assertions.assertTrue(contactService.addContact(contact));
        Assertions.assertEquals(1, contactService.getContacts().size());
    }

    @Test
    public void testAddDuplicateContactReturnsFalse() {
        // Adding the same ID twice should return false on the second attempt
        contactService.addContact(contact);
        Assertions.assertFalse(contactService.addContact(contact));
    }

    @Test
    public void testAddDuplicateDoesNotIncreasCount() {
        // The second add should not create a new entry
        contactService.addContact(contact);
        contactService.addContact(contact); // duplicate - should be ignored
        Assertions.assertEquals(1, contactService.getContacts().size());
    }

    // Delete tests

    @Test
    public void testDeleteContactSucceeds() {
        contactService.addContact(contact);
        Assertions.assertTrue(contactService.deleteContact("C001"));
        Assertions.assertEquals(0, contactService.getContacts().size());
    }

    @Test
    public void testDeleteNonExistentReturnsFalse() {
        // Trying to delete an ID that was never added should return false
        Assertions.assertFalse(contactService.deleteContact("NOTEXIST"));
    }

    // Update tests
    // Each test adds a contact, updates one field, then retrieves and verifies
    // the stored value actually changed

    @Test
    public void testUpdateFirstName() {
        contactService.addContact(contact);
        Assertions.assertTrue(contactService.updateContactFirstName("C001", "Mary"));
        Assertions.assertEquals("Mary", contactService.getContacts().get("C001").getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        contactService.addContact(contact);
        Assertions.assertTrue(contactService.updateContactLastName("C001", "Smith"));
        Assertions.assertEquals("Smith", contactService.getContacts().get("C001").getLastName());
    }

    @Test
    public void testUpdatePhoneNumber() {
        contactService.addContact(contact);
        Assertions.assertTrue(contactService.updateContactPhoneNumber("C001", "9998887777"));
        Assertions.assertEquals("9998887777", contactService.getContacts().get("C001").getPhoneNumber());
    }

    @Test
    public void testUpdateAddress() {
        contactService.addContact(contact);
        Assertions.assertTrue(contactService.updateContactAddress("C001", "456 Oak Ave"));
        Assertions.assertEquals("456 Oak Ave", contactService.getContacts().get("C001").getAddress());
    }

    @Test
    public void testUpdateNonExistentContactReturnsFalse() {
        // If the contact does not exist the update methods should return false
        Assertions.assertFalse(contactService.updateContactFirstName("NOTEXIST", "Mary"));
    }
}
