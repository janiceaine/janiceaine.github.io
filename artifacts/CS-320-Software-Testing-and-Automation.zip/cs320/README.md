# CS-320 Software Testing: CS-499 Enhanced Version

**Author:** Janice Ainembabazi
**Course:** CS-499 Computer Science Capstone
**Original Course:** CS-320 Software Testing and Automation
**School:** Southern New Hampshire University

---

## Overview

This project is the CS-499 Capstone enhancement of the CS-320 Software Testing final artifact. The original project contained three service classes — ContactService, TaskService, and AppointmentService, each backed by a simple HashMap. The enhancement adds two algorithm and data structure improvements to demonstrate knowledge of collections beyond basic HashMap usage.

---

## What Was Enhanced

### TaskService: PriorityQueue

A `priority` field (1=high, 2=medium, 3=low) was added to the `Task` model. `TaskService` gained two new methods:

- `getTasksByPriority()` — builds a `PriorityQueue<Task>` with a comparator on the priority field and returns all tasks sorted from most to least urgent
- `peekHighestPriorityTask()` — returns the most urgent task without removing it from storage

The existing `HashMap` is still used for all normal O(1) add, delete, and update operations. The `PriorityQueue` is built on demand at read time so no second structure has to be maintained in sync.

### AppointmentService — TreeMap

A `TreeMap<Date, Appointment>` was added alongside the existing `HashMap<String, Appointment>`. The `TreeMap` keeps appointments in chronological order automatically because `Date` implements `Comparable`. Two new methods were added:

- `getAppointmentsSortedByDate()` — returns all appointments in date order using `TreeMap.values()`
- `getNextAppointment()` — returns the earliest upcoming appointment using `TreeMap.firstEntry()` in O(log n) time

Both structures are kept in sync on every add and delete operation.

### Trade-off Notes

| Operation | HashMap | TreeMap |
|-----------|---------|---------|
| Insert | O(1) | O(log n) |
| Delete | O(1) | O(log n) |
| Lookup by key | O(1) | O(log n) |
| Get in sorted order | Not possible | O(n) |
| Get minimum/maximum | Not possible | O(log n) |

---

## Project Structure

```
cs320_final/
├── pom.xml
├── README.md
└── src/
    ├── main/java/org/snhu/cs320/
    │   ├── Main.java
    │   ├── contact/
    │   │   ├── Contact.java
    │   │   └── ContactService.java
    │   ├── task/
    │   │   ├── Task.java
    │   │   ├── TaskService.java
    │   │   └── TaskAlreadyExistsException.java
    │   └── appointment/
    │       ├── Appointment.java
    │       └── AppointmentService.java
    └── test/java/org/snhu/cs320/
        ├── contact/
        │   ├── ContactTest.java
        │   └── ContactServiceTest.java
        ├── task/
        │   ├── TaskTest.java
        │   └── TaskServiceTest.java
        └── appointment/
            ├── AppointmentTest.java
            └── AppointmentServiceTest.java
```

---

## How to Run

**Run the demo (shows sorting in action):**
```
mvn exec:java
```

**Run all JUnit tests:**
```
mvn test
```

**Requirements:** Java 21, Maven 3.8+
