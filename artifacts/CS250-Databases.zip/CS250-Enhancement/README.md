# CS-499 Artifact 3: Databases Enhancement
## Top Five Destination List with MongoDB Backend + Full Stack Web UI

**Name:** Janice Ainembabazi
**Course:** CS-499 Computer Science Capstone
**Original Artifact:** CS-250 Software Development Lifecycle

---

## What this project is

This project is the database enhancement for the CS-499 capstone ePortfolio. The original CS-250 artifact was a Java Swing application that displayed five travel destinations in a scrollable list with all data hardcoded directly in the Java source file.

This enhancement replaces that hardcoded data with a MongoDB database backend and adds a full stack web interface. The project now spans three languages and four layers:

```
MongoDB (destinations_db / destinations collection)
        |
   app.py              Flask REST API: all CRUD + analytical queries
        |          |
   index.html      destinations.json
   (web UI)        (Java Swing UI reads this on startup)
```

---

## Skills demonstrated

**Document-based data model (DAD-220)**
Each destination is a MongoDB document with seven fields chosen based on what the application queries: destination_id, name, description, image_file, url, category, and rating.

**PyMongo database interface (CS-340)**
app.py and db_interface.py both use PyMongo to connect to MongoDB and perform all database operations. All inputs are validated before any write runs.

**CRUD operations and analytical queries (DAD-220 + CS-340)**

| Operation | Endpoint | Function |
|---|---|---|
| Create | POST /api/destinations | insert_one() |
| Read all | GET /api/destinations | find() sorted by rating |
| Read one | GET /api/destinations/:id | find_one() |
| Update | PUT /api/destinations/:id | update_one() with $set |
| Delete | DELETE /api/destinations/:id | delete_one() |
| Top rated | GET /api/top?min_rating=4.5 | find() with $gte filter |
| Category summary | GET /api/summary | $group aggregation pipeline |

**MongoDB interface with HTML and JavaScript**
index.html is a single-page web application that calls the Flask API using the browser's fetch() API. It displays destinations as cards, lets the user add, edit, and delete records through a modal form, and filters by category using chip buttons.

**Full stack with multiple programming languages**
Python (Flask API) + HTML/JavaScript (web frontend) + MongoDB (database) + Java (original Swing UI) form a complete multi-language full stack application.

**Secure coding (CS-405)**
All inputs are validated in app.py before any database operation runs. The HTML UI also validates client-side before sending a request. The Java loader handles missing files and malformed JSON without crashing.

---

## Files

| File | Language | Purpose |
|---|---|---|
| app.py | Python | Flask REST API: replaces direct db_interface.py calls as the main entry point |
| index.html | HTML / JavaScript | Web UI with full CRUD through the Flask API |
| seed_db.py | Python | Inserts the five starter destination documents into MongoDB |
| db_interface.py | Python | Standalone CRUD functions and analytical queries (used by manage_destinations.py) |
| manage_destinations.py | Python | CLI menu for running CRUD operations from the terminal |
| TopFiveDestinationList.java | Java | Original Swing UI, reads destinations.json on startup |

---

## Requirements

- macOS with Homebrew (for MongoDB)
- Python 3.9 or later
- Java 21 or later
- json-simple-1.1.1.jar in the project root (for Java compilation only)

---

## Setup (one time only)

**1. Install and start MongoDB**

```bash
brew tap mongodb/brew
brew install mongodb-community
brew services start mongodb/brew/mongodb-community
```

**2. Create a Python virtual environment**

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install pymongo flask flask-cors
```

**3. Seed the database**

```bash
python seed_db.py
```

---

## Running the web UI (primary interface)

**Step 1. Start the Flask API**

```bash
source .venv/bin/activate
python app.py
```

The API starts at http://localhost:5000. Leave this terminal running.

**Step 2. Open the web UI**

Open index.html in your browser. The page loads all destinations from MongoDB through the Flask API and displays them as cards. Use the Add button to create new destinations, Edit to update them, and Delete to remove them. Every write operation also refreshes destinations.json automatically.

---

## Running the Java UI

The Java UI reads destinations.json and displays the same data. It updates automatically whenever the web UI or CLI makes a change, as long as you restart it.

```bash
javac --release 21 -cp .:json-simple-1.1.1.jar TopFiveDestinationList.java
java  -cp .:json-simple-1.1.1.jar TopFiveDestinationList
```

---

## Running the CLI tool

```bash
python manage_destinations.py
```

---

## API endpoints reference

| Method | Endpoint | Description |
|---|---|---|
| GET | /api/destinations | All destinations sorted by rating |
| GET | /api/destinations/:id | Single destination by ID |
| POST | /api/destinations | Add a new destination |
| PUT | /api/destinations/:id | Update fields on an existing destination |
| DELETE | /api/destinations/:id | Delete a destination |
| GET | /api/top?min_rating=4.5 | Destinations at or above the rating threshold |
| GET | /api/summary | Count and average rating grouped by category |

---

## Troubleshooting

**Web UI shows "Cannot reach API"**
Start app.py first: `python app.py`

**`Could not connect to MongoDB`**
Start MongoDB: `brew services start mongodb/brew/mongodb-community`

**`No destinations found` in Java UI**
The Java UI reads destinations.json. Make sure you have run seed_db.py and that at least one write has been made through the web UI or CLI to generate the file.

**CORS error in browser console**
flask-cors must be installed: `python -m pip install flask-cors`