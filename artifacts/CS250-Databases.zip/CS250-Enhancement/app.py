# app.py
# Flask REST API for the Top Five Destinations application.
# This file is the new entry point for the full stack enhancement.
# It connects to MongoDB using PyMongo and exposes HTTP endpoints
# that the HTML/JavaScript UI calls to read and write destination data.
# It also writes destinations.json after every change so the Java Swing
# UI stays in sync without any modification to that file.
#
# This enhancement adds two things to the Artifact 3 submission:
#   1. A MongoDB interface accessible through HTML and JavaScript
#   2. A full stack architecture spanning Python, JavaScript, and Java
#
# Run this file to start the API server and open the browser automatically.
#   python3 app.py
#
# Name:   Janice Ainembabazi
# Class:  CS-499 Computer Science Capstone
# Date:   2026

import json
import webbrowser
from flask import Flask, jsonify, request, render_template
from flask_cors import CORS
from pymongo import MongoClient, DESCENDING
from pymongo.errors import ConnectionFailure, DuplicateKeyError
import sys

# ---------------------------------------------------------------------------
# app setup
# ---------------------------------------------------------------------------

app = Flask(__name__)

# CORS allows the HTML page to call this API even when opened as a local file
CORS(app)

# ---------------------------------------------------------------------------
# connection settings
# ---------------------------------------------------------------------------

MONGO_URI   = "mongodb://localhost:27017/"
DB_NAME     = "destinations_db"
COL_NAME    = "destinations"
EXPORT_FILE = "destinations.json"


def get_col():
    """Connects to MongoDB and returns the destinations collection."""
    try:
        client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=3000)
        client.admin.command("ping")
        return client[DB_NAME][COL_NAME]
    except ConnectionFailure as e:
        print(f"ERROR: Cannot connect to MongoDB. Details: {e}")
        sys.exit(1)


def export_json(col):
    """
    Writes all destinations to destinations.json so the Java UI stays
    in sync after any add, update, or delete operation through the web UI.
    This is the same bridge pattern used in db_interface.py.
    """
    docs = list(col.find({}, {"_id": 0}).sort("rating", DESCENDING))
    with open(EXPORT_FILE, "w", encoding="utf-8") as f:
        json.dump(docs, f, indent=2, ensure_ascii=False)


def validate_destination_id(dest_id):
    """Checks destination_id is a non-empty string under 20 characters."""
    if not dest_id or not isinstance(dest_id, str) or len(dest_id.strip()) == 0:
        raise ValueError("destination_id must be a non-empty string.")
    if len(dest_id) > 20:
        raise ValueError("destination_id must be 20 characters or fewer.")
    return dest_id.strip()


def validate_rating(rating):
    """Checks rating is a number between 1.0 and 5.0."""
    try:
        r = float(rating)
    except (TypeError, ValueError):
        raise ValueError("Rating must be a number.")
    if r < 1.0 or r > 5.0:
        raise ValueError("Rating must be between 1.0 and 5.0.")
    return round(r, 1)


def validate_name(name):
    """Checks name is a non-empty string under 100 characters."""
    if not name or not isinstance(name, str) or len(name.strip()) == 0:
        raise ValueError("name must be a non-empty string.")
    if len(name) > 100:
        raise ValueError("name must be 100 characters or fewer.")
    return name.strip()


# ---------------------------------------------------------------------------
# serve the web UI
# ---------------------------------------------------------------------------

@app.route("/")
def home():
    """Serves index.html from the templates folder."""
    return render_template("index.html")


# ---------------------------------------------------------------------------
# READ: GET /api/destinations
# Returns all destinations sorted by rating descending.
# ---------------------------------------------------------------------------

@app.route("/api/destinations", methods=["GET"])
def get_destinations():
    col = get_col()
    docs = list(col.find({}, {"_id": 0}).sort("rating", DESCENDING))
    return jsonify(docs), 200


# ---------------------------------------------------------------------------
# READ ONE: GET /api/destinations/<destination_id>
# Returns a single destination by its ID.
# ---------------------------------------------------------------------------

@app.route("/api/destinations/<destination_id>", methods=["GET"])
def get_destination(destination_id):
    try:
        destination_id = validate_destination_id(destination_id)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    col = get_col()
    doc = col.find_one({"destination_id": destination_id}, {"_id": 0})
    if not doc:
        return jsonify({"error": f"No destination found with ID '{destination_id}'."}), 404
    return jsonify(doc), 200


# ---------------------------------------------------------------------------
# CREATE: POST /api/destinations
# Inserts a new destination document.
# Expects JSON body with all required fields.
# ---------------------------------------------------------------------------

@app.route("/api/destinations", methods=["POST"])
def add_destination():
    data = request.get_json()
    if not data:
        return jsonify({"error": "Request body must be JSON."}), 400

    # validating all fields before any database write (CS-405)
    try:
        destination_id = validate_destination_id(data.get("destination_id", ""))
        name           = validate_name(data.get("name", ""))
        rating         = validate_rating(data.get("rating", ""))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    description = data.get("description", "").strip()
    image_file  = data.get("image_file", "").strip()
    url         = data.get("url", "").strip()
    category    = data.get("category", "").strip()

    if not description:
        return jsonify({"error": "description is required."}), 400
    if not image_file:
        return jsonify({"error": "image_file is required."}), 400
    if not url:
        return jsonify({"error": "url is required."}), 400
    if not category:
        return jsonify({"error": "category is required."}), 400

    doc = {
        "destination_id": destination_id,
        "name":           name,
        "description":    description,
        "image_file":     image_file,
        "url":            url,
        "category":       category,
        "rating":         rating
    }

    col = get_col()
    try:
        col.insert_one(doc)
    except DuplicateKeyError:
        return jsonify({"error": f"A destination with ID '{destination_id}' already exists."}), 409

    export_json(col)
    return jsonify({"message": f"Added: {name}"}), 201


# ---------------------------------------------------------------------------
# UPDATE: PUT /api/destinations/<destination_id>
# Updates one or more fields on an existing destination.
# Only the fields included in the request body are changed.
# ---------------------------------------------------------------------------

@app.route("/api/destinations/<destination_id>", methods=["PUT"])
def update_destination(destination_id):
    try:
        destination_id = validate_destination_id(destination_id)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    data = request.get_json()
    if not data:
        return jsonify({"error": "Request body must be JSON."}), 400

    updates = {}

    # only include fields the caller actually sent
    for field in ["name", "description", "image_file", "url", "category", "rating"]:
        if field in data:
            updates[field] = data[field]

    # validating fields that have specific rules
    try:
        if "rating" in updates:
            updates["rating"] = validate_rating(updates["rating"])
        if "name" in updates:
            updates["name"] = validate_name(updates["name"])
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    if not updates:
        return jsonify({"error": "No valid fields provided for update."}), 400

    col = get_col()
    result = col.update_one(
        {"destination_id": destination_id},
        {"$set": updates}
    )

    if result.matched_count == 0:
        return jsonify({"error": f"No destination found with ID '{destination_id}'."}), 404

    export_json(col)
    return jsonify({"message": f"Updated '{destination_id}'."}), 200


# ---------------------------------------------------------------------------
# DELETE: DELETE /api/destinations/<destination_id>
# Removes a single destination document by ID.
# ---------------------------------------------------------------------------

@app.route("/api/destinations/<destination_id>", methods=["DELETE"])
def delete_destination(destination_id):
    try:
        destination_id = validate_destination_id(destination_id)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    col = get_col()
    result = col.delete_one({"destination_id": destination_id})

    if result.deleted_count == 0:
        return jsonify({"error": f"No destination found with ID '{destination_id}'."}), 404

    export_json(col)
    return jsonify({"message": f"Deleted '{destination_id}'."}), 200


# ---------------------------------------------------------------------------
# ANALYTICAL QUERY: GET /api/top?min_rating=4.5
# Returns destinations at or above the given rating threshold.
# ---------------------------------------------------------------------------

@app.route("/api/top", methods=["GET"])
def top_rated():
    try:
        min_rating = validate_rating(request.args.get("min_rating", 4.5))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    col = get_col()
    docs = list(
        col.find({"rating": {"$gte": min_rating}}, {"_id": 0})
           .sort("rating", DESCENDING)
    )
    return jsonify(docs), 200


# ---------------------------------------------------------------------------
# ANALYTICAL QUERY -- GET /api/summary
# Returns the count and average rating grouped by category.
# Uses the same aggregation pipeline as db_interface.py.
# ---------------------------------------------------------------------------

@app.route("/api/summary", methods=["GET"])
def category_summary():
    col = get_col()
    pipeline = [
        {"$group": {
            "_id":        "$category",
            "count":      {"$sum": 1},
            "avg_rating": {"$avg": "$rating"}
        }},
        {"$sort": {"avg_rating": -1}},
        {"$project": {
            "_id":        0,
            "category":   "$_id",
            "count":      1,
            "avg_rating": {"$round": ["$avg_rating", 2]}
        }}
    ]
    results = list(col.aggregate(pipeline))
    return jsonify(results), 200


# ---------------------------------------------------------------------------
# start the server and open the browser automatically
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("Starting Top Five Destinations API...")
    print("Opening browser at http://localhost:5000")
    webbrowser.open("http://localhost:8080")
app.run(debug=True, port=8080, host="0.0.0.0")