# seed_db.py
# Connects to a local MongoDB instance and inserts the five travel destination
# documents into the destinations_db database. This script only needs to run
# once. After the database is populated, db_interface.py handles all data
# access going forward.
#
# I learned how to structure seed scripts in CS-340, where we set up a MongoDB
# collection with starter data before writing any query logic. Separating the
# seed step from the interface layer keeps concerns clean and makes it easy to
# reset and reload the database independently.
#
# Name:   Janice Ainembabazi
# Class:  CS-499 Computer Science Capstone
# Date:   2026

from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, DuplicateKeyError
import sys

# ---------------------------------------------------------------------------
# connection settings
# These constants are defined at the top so they are easy to update in one
# place if the database name or host changes.
# ---------------------------------------------------------------------------

MONGO_URI = "mongodb://localhost:27017/"
DB_NAME   = "destinations_db"
COL_NAME  = "destinations"

# ---------------------------------------------------------------------------
# destination documents
# Each dictionary below represents one MongoDB document. In CS-340 I learned
# that MongoDB stores data as BSON documents, which map directly to Python
# dictionaries. The schema I designed here includes seven fields per document:
#
#   destination_id : unique string key used for all lookups and updates
#   name           : display name shown in the Java UI list
#   description    : one-sentence summary displayed next to the name
#   image_file     : filename of the image stored in the resources folder
#   url            : booking or information link opened on double-click
#   category       : broad travel category used in the aggregation query
#   rating         : traveler rating from 1.0 to 5.0, used for filtering
#
# I designed this schema based on what I learned in DAD-220 about choosing
# fields that match the queries the application actually needs to run. Every
# field here is either displayed in the UI, used in a filter, or used in the
# aggregation pipeline.
# ---------------------------------------------------------------------------

DESTINATIONS = [
    {
        "destination_id": "dest_001",
        "name":           "Paris Eiffel Tower",
        "description":    "The eldest tall tower in the world, standing in the heart of Paris.",
        "image_file":     "EiffelTower.jpg",
        "url":            "https://www.toureiffel.paris/en",
        "category":       "Landmark",
        "rating":         4.9
    },
    {
        "destination_id": "dest_002",
        "name":           "Virgin Atlantic Cruise Ship",
        "description":    "One of the best 5-star cruises in the world.",
        "image_file":     "VirginAtlanticCruiseShip.jpg",
        "url":            "https://www.virginvoyages.com",
        "category":       "Cruise",
        "rating":         4.7
    },
    {
        "destination_id": "dest_003",
        "name":           "Palace of Westminster",
        "description":    "Home to one of the most ancient parliamentary monarchies.",
        "image_file":     "Westminster.jpg",
        "url":            "https://www.parliament.uk/visiting/",
        "category":       "Landmark",
        "rating":         4.6
    },
    {
        "destination_id": "dest_004",
        "name":           "Oia Santorini",
        "description":    "Greece's famous whitewashed coastal town overlooking the Aegean Sea.",
        "image_file":     "OiaSantorini.jpg",
        "url":            "https://www.myfeetwillleadme.com/where-to-stay-in-santorini/",
        "category":       "Beach",
        "rating":         4.8
    },
    {
        "destination_id": "dest_005",
        "name":           "Lake Clearwater",
        "description":    "One of the best camping grounds in the world, located in New Zealand.",
        "image_file":     "LakeClearwater.jpg",
        "url":            "https://www.doc.govt.nz/parks-and-recreation/places-to-go",
        "category":       "Nature",
        "rating":         4.5
    }
]


def seed():
    """
    Connects to MongoDB, creates a unique index on destination_id, and inserts
    each destination document. If a document with the same destination_id already
    exists, it is skipped rather than duplicated.
    """

    # attempting the connection before doing any work so the error message is
    # clear if MongoDB is not running
    try:
        client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=3000)
        # ping() confirms the server is reachable; without this, errors only
        # surface on the first actual query, which makes debugging harder
        client.admin.command("ping")
    except ConnectionFailure as e:
        print(f"ERROR: Could not connect to MongoDB at {MONGO_URI}")
        print(f"       Make sure MongoDB is running. Details: {e}")
        sys.exit(1)

    col = client[DB_NAME][COL_NAME]

    # creating a unique index on destination_id so that running this script
    # a second time does not insert duplicate records
    # I learned about unique indexes in DAD-220 as a way to enforce data
    # integrity at the database level rather than relying on application code
    col.create_index("destination_id", unique=True)

    inserted = 0
    skipped  = 0

    for doc in DESTINATIONS:
        try:
            col.insert_one(doc)
            inserted += 1
            print(f"  inserted : {doc['name']}")
        except DuplicateKeyError:
            # a DuplicateKeyError means this destination_id already exists;
            # skipping is the right behavior so re-runs are safe
            skipped += 1
            print(f"  skipped  : {doc['name']} (already exists)")

    print(f"\nSeed complete.")
    print(f"  Inserted  : {inserted}")
    print(f"  Skipped   : {skipped}")
    print(f"  Database  : {DB_NAME}")
    print(f"  Collection: {COL_NAME}")

    client.close()


if __name__ == "__main__":
    seed()