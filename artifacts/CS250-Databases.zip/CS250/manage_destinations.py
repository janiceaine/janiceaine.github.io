# manage_destinations.py
# Command-line tool for managing destination records in MongoDB.
# Provides a simple text menu for running all four CRUD operations and the two
# analytical queries implemented in db_interface.py.
#
# This script is the demonstration layer for the CS-499 Artifact 3 enhancement.
# Running it shows that every CRUD operation works end to end: a new destination
# can be added, read back, updated, and deleted entirely from the command line,
# without touching the Java source code or the JSON file directly.
#
# After making any changes through this tool, run option 7 to export the updated
# data to destinations.json, then restart the Java UI to see the changes.
#
# Name:   Janice Ainembabazi
# Class:  CS-499 Computer Science Capstone
# Date:   2026

# importing the database interface module so this file only handles user input;
# all MongoDB logic stays in db_interface.py
import db_interface as db


def print_separator():
    """Prints a visual divider line to separate menu sections."""
    print("-" * 50)


def menu():
    """Displays the main menu and returns the user's choice as a string."""
    print("\n=== Destination Manager ===")
    print("1. List all destinations")
    print("2. Add a destination")
    print("3. Update a destination")
    print("4. Delete a destination")
    print("5. Top rated destinations")
    print("6. Category summary")
    print("7. Export to JSON (refresh UI data)")
    print("0. Exit")
    return input("Choice: ").strip()


def list_all():
    """
    Retrieves all destinations from MongoDB and prints them to the console.
    This demonstrates the Read operation from db_interface.get_all_destinations().
    """
    print_separator()
    destinations = db.get_all_destinations()
    if not destinations:
        print("No destinations in database.")
        return
    for d in destinations:
        print(f"  [{d['destination_id']}] {d['name']}")
        print(f"      Category : {d['category']}  |  Rating: {d['rating']}")
        print(f"      {d['description']}")
        print()


def add():
    """
    Prompts the user for all required fields and calls add_destination().
    Validation happens inside db_interface, so this function only collects
    the input and passes it along. Any validation error prints a message
    instead of crashing.
    This demonstrates the Create operation.
    """
    print_separator()
    print("Enter details for the new destination.")
    dest_id     = input("destination_id (e.g. dest_006): ").strip()
    name        = input("Name: ").strip()
    description = input("Description: ").strip()
    image_file  = input("Image filename (e.g. MyPhoto.jpg): ").strip()
    url         = input("URL: ").strip()
    category    = input("Category (Landmark / Beach / Nature / Cruise): ").strip()
    rating_str  = input("Rating (1.0 to 5.0): ").strip()

    try:
        db.add_destination(dest_id, name, description,
                           image_file, url, category, rating_str)
    except ValueError as e:
        print(f"Validation error: {e}")


def update():
    """
    Prompts the user for a destination_id and any fields to change.
    Blank entries are skipped so only the fields the user fills in are updated.
    This demonstrates the Update operation using $set in MongoDB.
    """
    print_separator()
    dest_id = input("destination_id to update: ").strip()
    print("Leave a field blank to keep the current value.")

    fields = {}

    name = input("New name: ").strip()
    if name:
        fields["name"] = name

    description = input("New description: ").strip()
    if description:
        fields["description"] = description

    category = input("New category: ").strip()
    if category:
        fields["category"] = category

    rating = input("New rating: ").strip()
    if rating:
        fields["rating"] = rating

    url = input("New url: ").strip()
    if url:
        fields["url"] = url

    if not fields:
        print("No changes entered.")
        return

    try:
        db.update_destination(dest_id, fields)
    except ValueError as e:
        print(f"Validation error: {e}")


def delete():
    """
    Prompts the user for a destination_id, asks for confirmation, then deletes
    the document if confirmed. The confirmation step prevents accidental deletes.
    This demonstrates the Delete operation.
    """
    print_separator()
    dest_id = input("destination_id to delete: ").strip()
    # asking for explicit confirmation before a destructive operation is a
    # practice I carried over from CS-405 secure coding habits
    confirm = input(f"Delete '{dest_id}'? Type yes to confirm: ").strip().lower()
    if confirm == "yes":
        db.delete_destination(dest_id)
    else:
        print("Cancelled.")


def top_rated():
    """
    Asks for a minimum rating threshold and prints all destinations that meet it.
    This demonstrates the get_top_rated() analytical query, which pushes
    filtering to MongoDB rather than loading all records first.
    """
    print_separator()
    min_r = input("Minimum rating (press Enter for default 4.5): ").strip()
    min_r = float(min_r) if min_r else 4.5
    results = db.get_top_rated(min_r)
    if not results:
        print(f"No destinations rated {min_r} or above.")
        return
    for d in results:
        print(f"  {d['name']}  |  Rating: {d['rating']}")


def category_summary():
    """
    Prints the aggregation pipeline results grouped by category.
    This demonstrates get_category_summary(), which uses a $group pipeline
    stage to compute counts and averages inside MongoDB.
    """
    print_separator()
    rows = db.get_category_summary()
    print(f"  {'Category':<12}  {'Count':>5}  {'Avg Rating':>10}")
    print_separator()
    for row in rows:
        print(f"  {row['category']:<12}  {row['count']:>5}  {row['avg_rating']:>10}")


def main():
    """
    Main loop. Reads the user's menu choice and calls the matching function.
    Runs until the user enters 0 to exit.
    """
    while True:
        choice = menu()
        if choice == "1":
            list_all()
        elif choice == "2":
            add()
        elif choice == "3":
            update()
        elif choice == "4":
            delete()
        elif choice == "5":
            top_rated()
        elif choice == "6":
            category_summary()
        elif choice == "7":
            db.export_to_json()
        elif choice == "0":
            print("Goodbye.")
            break
        else:
            print("Invalid choice. Enter a number from the menu.")


if __name__ == "__main__":
    main()