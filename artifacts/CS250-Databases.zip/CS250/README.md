# CS-499 Artifact 3: Databases Enhancement
## Top Five Destination List with MongoDB Backend

**Name:** Janice Ainembabazi
**Course:** CS-499 Computer Science Capstone
**Original Artifact:** CS-250 Software Development Lifecycle

---

## What this project is

This project is the database enhancement for my CS-499 capstone ePortfolio. The original CS-250 artifact was a Java Swing application displaying five travel destinations in a scrollable list. All destination data was hardcoded directly in the Java source file. To change any field, the source had to be edited and recompiled.

This enhancement replaces that hardcoded data with a MongoDB database backend. Destination records live in a MongoDB collection. A Python module built with PyMongo handles all database operations. The Java UI reads a JSON file that Python exports, so the UI always reflects whatever is currently in the database.

---

## Skills demonstrated

**Document-based data model (DAD-220)**
Each destination is stored as a MongoDB document with seven fields: destination_id, name, description, image_file, url, category, and rating. The schema was designed based on what DAD-220 taught about choosing fields that match the queries the application actually needs, rather than mirroring a relational table structure.

**PyMongo database interface (CS-340)**
`db_interface.py` connects to MongoDB using PyMongo and provides all four CRUD operations along with two analytical queries. CS-340 taught me how to use find(), update_one(), delete_one(), and the aggregation pipeline, all of which are applied here.

**CRUD operations and analytical queries (DAD-220 + CS-340)**

| Operation | Function | MongoDB method |
|---|---|---|
| Create | add_destination() | insert_one() |
| Read | get_all_destinations(), get_destination_by_id() | find(), find_one() |
| Update | update_destination() | update_one() with $set |
| Delete | delete_destination() | delete_one() |
| Query | get_top_rated() | find() with $gte filter |
| Aggregate | get_category_summary() | aggregate() with $group pipeline |

**Secure coding (CS-405)**
All user inputs are validated in db_interface.py before any database operation runs. The Java UI handles missing files, malformed JSON, and missing fields without crashing, returning empty results or showing a dialog instead.

---

## Architecture

```
MongoDB (destinations_db / destinations collection)
        |
   db_interface.py     PyMongo layer: CRUD + analytical queries
        |
   destinations.json   JSON bridge (Python writes, Java reads)
        |
TopFiveDestinationList.java   Java Swing UI
```

The Java application does not connect to MongoDB directly. Python writes destination data to `destinations.json` and Java reads that file on startup. This keeps database logic in Python, where PyMongo and CS-340 skills apply, and display logic in Java, where the original CS-250 Swing code lives.

---

## Files

| File | Language | Purpose |
|---|---|---|
| seed_db.py | Python | Inserts the five starter destination documents into MongoDB |
| db_interface.py | Python | CRUD operations and analytical queries via PyMongo |
| manage_destinations.py | Python | CLI menu for running all CRUD operations interactively |
| TopFiveDestinationList.java | Java | Swing UI that reads destinations.json and renders the list |
| destinations.json | JSON | Bridge file written by Python, read by Java |

---

## Requirements

- macOS with Homebrew (instructions below use Homebrew for MongoDB)
- Python 3.9 or later
- Java 21 or later
- `json-simple-1.1.1.jar` in the project root folder

---

## Setup (one time only)

**1. Install and start MongoDB**

```bash
brew tap mongodb/brew
brew install mongodb-community
brew services start mongodb/brew/mongodb-community
```

Verify MongoDB is running:

```bash
mongosh --eval "db.runCommand({ ping: 1 })"
```

**2. Create a Python virtual environment**

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install pymongo
```

**3. Confirm image assets are in the resources folder**

The Java UI loads images from a `resources/` subfolder on the classpath. Place the five destination images there before running:

```
resources/
  EiffelTower.jpg
  VirginAtlanticCruiseShip.jpg
  Westminster.jpg
  OiaSantorini.jpg
  LakeClearwater.jpg
```

---

## Running the project

**Step 1. Seed the database (run once)**

```bash
source .venv/bin/activate
python seed_db.py
```

Expected output:
```
  inserted : Paris Eiffel Tower
  inserted : Virgin Atlantic Cruise Ship
  inserted : Palace of Westminster
  inserted : Oia Santorini
  inserted : Lake Clearwater

Seed complete.
  Inserted  : 5
  Skipped   : 0
```

Re-running seed_db.py is safe. Existing records are skipped, not duplicated.

**Step 2. Export destination data to JSON**

```bash
python db_interface.py
```

This writes `destinations.json` to the current directory. The Java UI reads this file on startup.

**Step 3. Compile the Java UI**

```bash
javac --release 21 -cp .:json-simple-1.1.1.jar TopFiveDestinationList.java
```

**Step 4. Run the Java UI**

```bash
java -cp .:json-simple-1.1.1.jar TopFiveDestinationList
```

The list window opens. Double-click any destination to open its URL in the browser.

---

## Managing destinations

Run the CLI tool to add, update, or delete records interactively:

```bash
python manage_destinations.py
```

Menu options:

```
1. List all destinations
2. Add a destination
3. Update a destination
4. Delete a destination
5. Top rated destinations (analytical query)
6. Category summary (aggregation pipeline)
7. Export to JSON (refresh UI data)
0. Exit
```

After making any changes, use option 7 to regenerate `destinations.json`, then restart the Java UI to see the updates.

---

## MongoDB document schema

| Field | Type | Notes |
|---|---|---|
| destination_id | string | Unique key, max 20 characters, indexed |
| name | string | Display name, max 100 characters |
| description | string | One-sentence summary |
| image_file | string | Filename inside the resources folder |
| url | string | Booking or information link |
| category | string | Landmark, Beach, Nature, or Cruise |
| rating | float | 1.0 to 5.0 |

---

## Troubleshooting

**`Could not connect to MongoDB at mongodb://localhost:27017/`**
Start MongoDB: `brew services start mongodb/brew/mongodb-community`

**`No destinations found` dialog when the Java UI launches**
Run `python db_interface.py` to generate `destinations.json` before starting the Java application.

**`package org.json.simple does not exist`**
Include the jar in the classpath: `javac -cp .:json-simple-1.1.1.jar ...`

**`UnsupportedClassVersionError` at runtime**
Recompile with `javac --release 21 ...` to match the Java version installed.

**`zsh: command not found: pip`**
Use `python -m pip` or activate the virtual environment first with `source .venv/bin/activate`.

**`externally-managed-environment` error during pip install**
You are trying to install into system Python. Use the project virtual environment instead.