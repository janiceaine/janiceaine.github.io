# db_interface.py
# PyMongo interface for the destinations_db MongoDB database.
# This file is the core of the CS-499 Artifact 3 database enhancement.
# It provides all four CRUD operations and two analytical queries, and
# exports destination data to a JSON file that the Java Swing UI reads.
#
# This module is the direct application of what I studied in two courses:
#
#   DAD-220: Taught me how to think about databases: how to design a schema,
#            what CRUD operations are, and why queries should be pushed to the
#            database rather than filtered in application code.
#
#   CS-340:  Taught me how to implement those ideas using Python and MongoDB.
#            I learned how to connect with PyMongo, write find() and update_one()
#            calls, and build aggregation pipelines for grouped queries.
#
# CS-405 Secure Coding is also applied here: every input is validated before
# any database operation runs, so bad data cannot be written to the collection.
#
# Name:   Janice Ainembabazi
# Class:  CS-499 Computer Science Capstone
# Date:   2026

import json
import sys
from pymongo import MongoClient, DESCENDING
from pymongo.errors import ConnectionFailure, DuplicateKeyError

# ---------------------------------------------------------------------------
# connection settings
# Keeping these as module-level constants makes them easy to change in one
# place without hunting through the code.
# ---------------------------------------------------------------------------

MONGO_URI   = "mongodb://localhost:27017/"
DB_NAME     = "destinations_db"
COL_NAME    = "destinations"
EXPORT_FILE = "destinations.json"


# ---------------------------------------------------------------------------
# internal helpers
# These functions are prefixed with _ to indicate they are private to this
# module. Other files call the public CRUD functions below, not these.
# ---------------------------------------------------------------------------

def _get_collection():
    """
    Connects to MongoDB and returns the destinations collection and the client.
    The caller is responsible for calling client.close() when finished.
    Exits the program with a clear message if the connection fails.
    """
    # I learned in CS-340 that serverSelectionTimeoutMS prevents the program
    # from hanging indefinitely when MongoDB is not running. Three seconds is
    # enough time for a local connection to either succeed or fail clearly.
    try:
        client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=3000)
        client.admin.command("ping")
        return client[DB_NAME][COL_NAME], client
    except ConnectionFailure as e:
        print(f"ERROR: Cannot connect to MongoDB at {MONGO_URI}")
        print(f"       Make sure MongoDB is running. Details: {e}")
        sys.exit(1)


def _validate_destination_id(dest_id):
    """
    Checks that destination_id is a non-empty string of 20 characters or fewer.
    Raises ValueError with a descriptive message if validation fails.
    """
    # CS-405 taught me to validate inputs at the boundary before they touch
    # any data store. Checking here means the database never receives blank
    # or oversized keys regardless of where the call comes from.
    if not dest_id or not isinstance(dest_id, str):
        raise ValueError("destination_id must be a non-empty string.")
    if len(dest_id.strip()) == 0:
        raise ValueError("destination_id cannot be blank.")
    if len(dest_id) > 20:
        raise ValueError("destination_id must be 20 characters or fewer.")
    return dest_id.strip()


def _validate_name(name):
    """
    Checks that name is a non-empty string of 100 characters or fewer.
    Raises ValueError with a descriptive message if validation fails.
    """
    if not name or not isinstance(name, str) or len(name.strip()) == 0:
        raise ValueError("name must be a non-empty string.")
    if len(name) > 100:
        raise ValueError("name must be 100 characters or fewer.")
    return name.strip()


def _validate_rating(rating):
    """
    Checks that rating can be converted to a float between 1.0 and 5.0.
    Raises ValueError with a descriptive message if validation fails.
    """
    try:
        r = float(rating)
    except (TypeError, ValueError):
        raise ValueError("Rating must be a number.")
    if r < 1.0 or r > 5.0:
        raise ValueError("Rating must be between 1.0 and 5.0.")
    # rounding to one decimal place keeps ratings consistent in the database
    return round(r, 1)


# ---------------------------------------------------------------------------
# CREATE
# ---------------------------------------------------------------------------

def add_destination(destination_id, name, description, image_file,
                    url, category, rating):
    """
    Inserts a new destination document into the MongoDB collection.
    All fields are validated before the insert runs.
    Returns True on success, False if destination_id already exists.
    Raises ValueError if any field fails validation.

    This is the Create operation in CRUD, as defined in DAD-220.
    In MongoDB, insert_one() adds a single document to the collection.
    """
    # validating every field before touching the database (CS-405 principle:
    # validate inputs at the boundary, before any write operation)
    destination_id = _validate_destination_id(destination_id)
    name           = _validate_name(name)
    rating         = _validate_rating(rating)

    if not description or not isinstance(description, str):
        raise ValueError("description must be a non-empty string.")
    if not image_file or not isinstance(image_file, str):
        raise ValueError("image_file must be a non-empty string.")
    if not url or not isinstance(url, str):
        raise ValueError("url must be a non-empty string.")
    if not category or not isinstance(category, str):
        raise ValueError("category must be a non-empty string.")

    col, client = _get_collection()

    # building the document as a Python dictionary; PyMongo converts this
    # to BSON when it sends it to MongoDB
    doc = {
        "destination_id": destination_id,
        "name":           name,
        "description":    description.strip(),
        "image_file":     image_file.strip(),
        "url":            url.strip(),
        "category":       category.strip(),
        "rating":         rating
    }

    try:
        col.insert_one(doc)
        print(f"Added: {name}")
        client.close()
        return True
    except DuplicateKeyError:
        # the unique index on destination_id prevents duplicates at the
        # database level; catching the error here gives a clean message
        print(f"A destination with ID '{destination_id}' already exists.")
        client.close()
        return False


# ---------------------------------------------------------------------------
# READ
# ---------------------------------------------------------------------------

def get_all_destinations():
    """
    Retrieves all destination documents sorted by rating, highest first.
    The {"_id": 0} projection tells MongoDB not to include the internal
    _id field in the results, which I learned in CS-340.

    This is the Read operation in CRUD, as defined in DAD-220.
    """
    col, client = _get_collection()
    # sort() with DESCENDING puts the highest-rated destinations first,
    # which matches the "Top 5" intent of the original CS-250 application
    results = list(col.find({}, {"_id": 0}).sort("rating", DESCENDING))
    client.close()
    return results


def get_destination_by_id(destination_id):
    """
    Retrieves a single destination document by its destination_id.
    Returns the document as a dictionary, or None if not found.

    find_one() is more efficient than find() when only one result is needed
    because MongoDB stops searching after the first match.
    """
    destination_id = _validate_destination_id(destination_id)
    col, client = _get_collection()
    doc = col.find_one({"destination_id": destination_id}, {"_id": 0})
    client.close()
    if not doc:
        print(f"No destination found with ID '{destination_id}'.")
    return doc


# ---------------------------------------------------------------------------
# UPDATE
# ---------------------------------------------------------------------------

def update_destination(destination_id, updates):
    """
    Updates one or more fields on an existing destination document.
    Only the fields in the updates dictionary are changed; everything else
    stays the same. The $set operator in MongoDB does a partial update,
    which I learned about in CS-340.

    Returns True if a document was modified, False otherwise.
    Raises ValueError if any updated field fails validation.

    This is the Update operation in CRUD, as defined in DAD-220.
    """
    destination_id = _validate_destination_id(destination_id)

    if not updates or not isinstance(updates, dict):
        raise ValueError("updates must be a non-empty dictionary.")

    # validating the fields most likely to receive bad values
    if "rating" in updates:
        updates["rating"] = _validate_rating(updates["rating"])
    if "name" in updates:
        updates["name"] = _validate_name(updates["name"])

    # preventing destination_id and _id from being changed through an update;
    # these are identity fields that should never be overwritten
    updates.pop("destination_id", None)
    updates.pop("_id", None)

    col, client = _get_collection()

    # $set updates only the fields listed in the dictionary, leaving all
    # other fields in the document untouched
    result = col.update_one(
        {"destination_id": destination_id},
        {"$set": updates}
    )
    client.close()

    if result.matched_count == 0:
        print(f"No destination found with ID '{destination_id}'.")
        return False
    if result.modified_count == 0:
        # matched but not modified means the new values were the same as
        # the existing ones; this is not an error, just informational
        print("No changes were made (values may already match).")
        return False

    print(f"Updated destination '{destination_id}'.")
    return True


# ---------------------------------------------------------------------------
# DELETE
# ---------------------------------------------------------------------------

def delete_destination(destination_id):
    """
    Deletes a single destination document by its destination_id.
    Returns True if deleted, False if no matching document was found.

    This is the Delete operation in CRUD, as defined in DAD-220.
    delete_one() is used instead of delete_many() to avoid accidentally
    removing more than one record.
    """
    destination_id = _validate_destination_id(destination_id)

    col, client = _get_collection()
    result = col.delete_one({"destination_id": destination_id})
    client.close()

    if result.deleted_count == 0:
        print(f"No destination found with ID '{destination_id}'.")
        return False

    print(f"Deleted destination '{destination_id}'.")
    return True


# ---------------------------------------------------------------------------
# ANALYTICAL QUERIES
# ---------------------------------------------------------------------------

def get_top_rated(min_rating=4.5):
    """
    Returns all destinations with a rating at or above min_rating, sorted
    highest first. The filter is applied inside MongoDB using $gte rather
    than loading all records and filtering in Python.

    In CS-340 I learned that pushing filter logic to the database is more
    efficient because MongoDB only sends back the documents that match,
    rather than sending everything and letting Python discard the rest.
    """
    min_rating = _validate_rating(min_rating)
    col, client = _get_collection()

    # $gte means "greater than or equal to" in MongoDB query syntax
    results = list(
        col.find(
            {"rating": {"$gte": min_rating}},
            {"_id": 0}
        ).sort("rating", DESCENDING)
    )
    client.close()
    return results


def get_category_summary():
    """
    Runs a MongoDB aggregation pipeline that groups destinations by category
    and returns the count and average rating for each group.

    In CS-340 I learned that aggregation pipelines work like a series of steps
    that MongoDB runs in order on the collection. The three stages here are:
      $group  : groups documents by category and computes count and avg rating
      $sort   : orders the groups by average rating, highest first
      $project: reshapes the output and renames the _id field to category
    """
    col, client = _get_collection()

    pipeline = [
        {
            # grouping by the category field and computing summary values
            "$group": {
                "_id":        "$category",
                "count":      {"$sum": 1},
                "avg_rating": {"$avg": "$rating"}
            }
        },
        {
            # sorting by average rating descending so the best categories
            # appear first in the output
            "$sort": {"avg_rating": -1}
        },
        {
            # projecting renames _id to category and rounds avg_rating to
            # two decimal places for clean display
            "$project": {
                "_id":        0,
                "category":   "$_id",
                "count":      1,
                "avg_rating": {"$round": ["$avg_rating", 2]}
            }
        }
    ]

    results = list(col.aggregate(pipeline))
    client.close()
    return results


# ---------------------------------------------------------------------------
# JSON EXPORT
# ---------------------------------------------------------------------------

def export_to_json(filepath=EXPORT_FILE):
    """
    Writes all destination documents to a JSON file.
    The Java Swing UI reads this file on startup instead of connecting to
    MongoDB directly. This keeps the database logic in Python and the display
    logic in Java, with the JSON file as the handoff point between them.

    I chose this architecture because it applies the separation of concerns
    principle I studied in CS-330: each layer does one job and does not reach
    into the other layer's responsibility.
    """
    destinations = get_all_destinations()

    if not destinations:
        print("WARNING: No destinations found in database. JSON file will be empty.")

    try:
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(destinations, f, indent=2, ensure_ascii=False)
        print(f"Exported {len(destinations)} destination(s) to {filepath}")
        return True
    except OSError as e:
        print(f"ERROR: Could not write to {filepath}. Details: {e}")
        return False


# ---------------------------------------------------------------------------
# smoke test
# Run this file directly to verify the database connection and all queries.
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("=== get_all_destinations ===")
    for d in get_all_destinations():
        print(f"  {d['destination_id']}  {d['name']}  rating={d['rating']}")

    print("\n=== get_top_rated(4.7) ===")
    for d in get_top_rated(4.7):
        print(f"  {d['name']}  {d['rating']}")

    print("\n=== get_category_summary ===")
    for row in get_category_summary():
        print(f"  {row['category']}  count={row['count']}  avg={row['avg_rating']}")

    print("\n=== export_to_json ===")
    export_to_json()